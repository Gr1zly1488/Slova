// ⚠️ ДЕМО-ВЕРСИЯ - ТОЛЬКО ДЛЯ ОБУЧЕНИЯ
// Реальные приложения требуют: двухфакторной аутентификации, аудита безопасности

import { Schema, model, Document } from 'mongoose';
import bcrypt from 'bcryptjs';

// ============ TYPESCRIPT INTERFACE ============
export interface IUser extends Document {
  email: string;
  username: string;
  passwordHash: string;
  balance: number; // В USD
  totalWins: number;
  totalLosses: number;
  totalGamesPlayed: number;
  mmr: number; // Matchmaking Rating (опционально для рейтинг-системы)
  isVerified: boolean;
  lastLogin?: Date;
  createdAt: Date;
  updatedAt: Date;

  // Methods
  comparePassword(candidatePassword: string): Promise<boolean>;
  toJSON(): Partial<IUser>;
}

// ============ MONGOOSE SCHEMA ============
const userSchema = new Schema<IUser>(
  {
    email: {
      type: String,
      required: [true, 'Email обязателен'],
      unique: true,
      lowercase: true,
      trim: true,
      match: [/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, 'Пожалуйста, укажите корректный email'],
      index: true,
    },

    username: {
      type: String,
      required: [true, 'Имя пользователя обязательно'],
      unique: true,
      trim: true,
      minlength: [3, 'Имя пользователя должно быть минимум 3 символа'],
      maxlength: [30, 'Имя пользователя не должно быть больше 30 символов'],
      match: [/^[a-zA-Z0-9_-]+$/, 'Имя пользователя может содержать только буквы, цифры, - и _'],
      index: true,
    },

    passwordHash: {
      type: String,
      required: [true, 'Пароль обязателен'],
      minlength: [6, 'Пароль должен быть минимум 6 символов'],
      select: false, // Не выбирать по умолчанию при запросах
    },

    balance: {
      type: Number,
      required: true,
      default: 0,
      min: [0, 'Баланс не может быть отрицательным'],
      set: (value: number) => parseFloat(value.toFixed(2)), // Округляем до 2 знаков
    },

    totalWins: {
      type: Number,
      required: true,
      default: 0,
      min: 0,
    },

    totalLosses: {
      type: Number,
      required: true,
      default: 0,
      min: 0,
    },

    totalGamesPlayed: {
      type: Number,
      required: true,
      default: 0,
      min: 0,
    },

    mmr: {
      type: Number,
      required: true,
      default: 1000, // Стандартный начальный рейтинг
      min: 0,
    },

    isVerified: {
      type: Boolean,
      default: false,
    },

    lastLogin: {
      type: Date,
      default: null,
    },
  },
  {
    timestamps: true, // Автоматически создаёт createdAt и updatedAt
    collection: 'users',
  }
);

// ============ ИНДЕКСЫ ДЛЯ ПРОИЗВОДИТЕЛЬНОСТИ ============
userSchema.index({ email: 1 });
userSchema.index({ username: 1 });
userSchema.index({ mmr: -1 }); // Для лидербордов

// ============ MIDDLEWARE - ХЕШИРОВАНИЕ ПАРОЛЯ ============
userSchema.pre('save', async function (next) {
  // Если пароль не изменён, переходим дальше
  if (!this.isModified('passwordHash')) {
    return next();
  }

  try {
    // Генерируем соль и хешируем пароль
    const salt = await bcrypt.genSalt(10);
    this.passwordHash = await bcrypt.hash(this.passwordHash, salt);
    next();
  } catch (error) {
    next(error as Error);
  }
});

// ============ МЕТОДЫ СХЕМЫ ============

/**
 * Сравнивает введённый пароль с хешированным паролем в БД
 * @param candidatePassword - пароль для проверки
 * @returns true если пароли совпадают, false в противном случае
 */
userSchema.methods.comparePassword = async function (
  candidatePassword: string
): Promise<boolean> {
  return bcrypt.compare(candidatePassword, this.passwordHash);
};

/**
 * Преобразует документ пользователя в JSON без чувствительных данных
 */
userSchema.methods.toJSON = function () {
  const obj = this.toObject();
  delete obj.passwordHash;
  return obj;
};

// ============ ВИРТУАЛЬНЫЕ ПОЛЯ ============

/**
 * Вычисляемое поле: процент побед
 */
userSchema.virtual('winRate').get(function () {
  if (this.totalGamesPlayed === 0) return 0;
  return ((this.totalWins / this.totalGamesPlayed) * 100).toFixed(2);
});

// ============ EXPORT ============
export const User = model<IUser>('User', userSchema);