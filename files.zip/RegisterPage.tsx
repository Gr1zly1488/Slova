import { AuthGuard } from '../components/auth/AuthGuard';
import { RegisterForm } from '../components/auth/RegisterForm';

/**
 * Страница регистрации нового аккаунта
 */
export const RegisterPage = () => {
  return (
    <AuthGuard>
      <div className="space-y-4">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">🎮 Слова</h1>
          <p className="text-gray-400">Создайте аккаунт и начните играть</p>
        </div>

        <RegisterForm />

        <p className="text-center text-gray-400 text-sm">
          Уже есть аккаунт?{' '}
          <a href="/login" className="text-blue-400 hover:text-blue-300">
            Войдите
          </a>
        </p>

        <div className="bg-yellow-900/20 border border-yellow-700/50 rounded-lg p-4 text-sm">
          <p className="text-yellow-300">
            ⚠️ <strong>Демо версия</strong> - только для обучения. Реальные игры требуют лицензирования.
          </p>
        </div>
      </div>
    </AuthGuard>
  );
};

export default RegisterPage;