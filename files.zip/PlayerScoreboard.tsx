interface PlayerScoreboardProps {
  player1Name: string;
  player2Name: string;
  player1Score: number;
  player2Score: number;
}

/**
 * Компонент счётной доски
 */
export const PlayerScoreboard = ({
  player1Name,
  player2Name,
  player1Score,
  player2Score,
}: PlayerScoreboardProps) => {
  return (
    <div className="flex justify-between items-center bg-slate-800/50 rounded-lg p-4">
      <div className="flex-1 text-center">
        <p className="text-sm text-gray-400">{player1Name}</p>
        <p className="text-3xl font-black text-blue-400">{player1Score}</p>
      </div>

      <div className="flex-1 text-center">
        <p className="text-sm text-gray-400">РОУНд</p>
        <p className="text-3xl font-black text-gray-400">VS</p>
      </div>

      <div className="flex-1 text-center">
        <p className="text-sm text-gray-400">{player2Name}</p>
        <p className="text-3xl font-black text-pink-400">{player2Score}</p>
      </div>
    </div>
  );
};