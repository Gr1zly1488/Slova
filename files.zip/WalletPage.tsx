import { DepositForm } from '../components/wallet/DepositForm';
import { TransactionHistory } from '../components/wallet/TransactionHistory';
import { WalletStats } from '../components/wallet/WalletStats';
import { useAppSelector } from '../store/store';

/**
 * Страница кошелька и платежей
 */
export const WalletPage = () => {
  const { user } = useAppSelector((state) => state.auth);

  if (!user) {
    return <div className="text-white text-center">⏳ Загрузка...</div>;
  }

  return (
    <div className="max-w-4xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Левая колонка - Форма депозита */}
      <div className="lg:col-span-2 space-y-8">
        <div className="bg-slate-800 rounded-lg p-8 border border-slate-700">
          <h1 className="text-3xl font-bold mb-6">💳 Пополнить баланс</h1>
          <DepositForm />
        </div>

        <div className="bg-slate-800 rounded-lg p-8 border border-slate-700">
          <h2 className="text-2xl font-bold mb-6">📜 История транзакций</h2>
          <TransactionHistory />
        </div>
      </div>

      {/* Правая колонка - Статистика */}
      <div>
        <WalletStats balance={user.balance} />
      </div>
    </div>
  );
};

export default WalletPage;