/**
 * Футер приложения
 */
const Footer = () => {
  return (
    <footer className="bg-slate-800 border-t border-slate-700 mt-12">
      <div className="container mx-auto px-4 py-8 text-center text-gray-400 text-sm">
        <p className="mb-2">
          © {new Date().getFullYear()} Слова - Демо версия для обучения
        </p>
        <p className="text-yellow-600/80">
          ⚠️ Реальные азартные игры требуют лицензирования и KYC/AML проверок
        </p>
      </div>
    </footer>
  );
};

export default Footer;