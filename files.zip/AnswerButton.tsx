interface AnswerButtonProps {
  index: number;
  text: string;
  isSelected: boolean;
  onClick: () => void;
  disabled: boolean;
}

const ANSWER_LETTERS = ['A', 'B', 'В', 'Г'];

/**
 * Компонент кнопки ответа
 */
export const AnswerButton = ({
  index,
  text,
  isSelected,
  onClick,
  disabled,
}: AnswerButtonProps) => {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`
        w-full p-4 rounded-xl border-2 transition duration-300 text-left
        flex items-center space-x-4 font-medium
        ${isSelected
          ? 'bg-blue-600 border-blue-400 shadow-lg shadow-blue-500/50'
          : 'bg-slate-700/50 border-slate-600 hover:border-slate-500 hover:bg-slate-700'
        }
        ${disabled && 'opacity-75 cursor-not-allowed'}
      `}
    >
      {/* Буква ответа */}
      <div
        className={`
          w-10 h-10 rounded-lg flex items-center justify-center font-bold text-sm
          ${isSelected
            ? 'bg-blue-400 text-blue-900'
            : 'bg-slate-600 text-white'
          }
        `}
      >
        {ANSWER_LETTERS[index]}
      </div>

      {/* Текст ответа */}
      <span className="flex-1">{text}</span>

      {/* Иконка выбора */}
      {isSelected && (
        <span className="text-xl">✓</span>
      )}
    </button>
  );
};