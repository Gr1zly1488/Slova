import { useAppSelector, useAppDispatch } from '../../store/store';
import { removeNotification } from '../../store/slices/notificationSlice';

/**
 * Компонент отображения уведомлений
 */
export const Notification = () => {
  const dispatch = useAppDispatch();
  const { notifications } = useAppSelector((state) => state.notification);

  return (
    <div className="fixed top-4 right-4 z-50 space-y-2 max-w-md">
      {notifications.map((notification) => {
        const bgColor = {
          success: 'bg-green-600',
          error: 'bg-red-600',
          info: 'bg-blue-600',
          warning: 'bg-yellow-600',
        }[notification.type];

        const icon = {
          success: '✅',
          error: '❌',
          info: 'ℹ️',
          warning: '⚠️',
        }[notification.type];

        return (
          <div
            key={notification.id}
            className={`${bgColor} text-white px-6 py-4 rounded-lg shadow-lg flex items-center justify-between animate-slide-in`}
          >
            <div className="flex items-center space-x-3">
              <span className="text-xl">{icon}</span>
              <span>{notification.message}</span>
            </div>
            <button
              onClick={() => dispatch(removeNotification(notification.id!))}
              className="text-white/70 hover:text-white text-xl"
            >
              ✕
            </button>
          </div>
        );
      })}
    </div>
  );
};