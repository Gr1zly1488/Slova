import { GameHandler } from './sockets/gameHandler';

// После инициализации io:

io.on('connection', (socket) => {
  console.log(`📡 Клиент подключен: ${socket.id}`);

  // Регистрируем все игровые обработчики
  GameHandler.registerHandlers(io, socket);
});