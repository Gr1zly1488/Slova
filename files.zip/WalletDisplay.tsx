interface WalletDisplayProps {
  user: any;
  onDepositClick: () => void;
}

/**
 * Компонент отображения баланса
 */
export const WalletDisplay = ({ user, onDepositClick }: WalletDisplayProps) => {
  return (
    <div className="bg-gradient-to-br from-blue-900/40 to-purple-900/40 backdrop-blur-sm rounded-2xl p-6 border border-blue-700/50">
      <h3 className="text-sm text-gray-400 mb-3">Ваш баланс</h3>

      <div className="mb-6">
        <div className="text-4xl font-black bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
          ${user?.balance.toFixed(2) || '0.00'}
        </div>
        <p className="text-xs text-gray-400 mt-2">USD</p>
      </div>

      <button
        onClick={onDepositClick}
        className="w-full px-4 py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 rounded-xl font-bold transition transform hover:scale-105 mb-3"
      >
        💳 Пополнить баланс
      </button>

      <div className="grid grid-cols-2 gap-3 text-xs">
        <div className="bg-slate-800/50 rounded-lg p-3 text-center">
          <div className="text-gray-400">Выведено</div>
          <div className="font-bold text-green-400">$0.00</div>
        </div>
        <div className="bg-slate-800/50 rounded-lg p-3 text-center">
          <div className="text-gray-400">На игру</div>
          <div className="font-bold text-yellow-400">$0.00</div>
        </div>
      </div>
    </div>
  );
};