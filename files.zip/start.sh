#!/bin/bash

echo "🎮 ЗАПУСК ПРОЕКТА СЛОВА"
echo "======================="

# Проверяем Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js не установлен!"
    echo "Скачайте с https://nodejs.org/"
    exit 1
fi

echo "✅ Node.js версия: $(node -v)"

# Backend
echo ""
echo "🔧 Запуск Backend..."
cd backend
if [ ! -d "node_modules" ]; then
    echo "📦 Установка зависимостей Backend..."
    npm install
fi

if [ ! -f ".env" ]; then
    echo "📝 Создание .env файла из примера..."
    cp .env.example .env
    echo "⚠️  ОТРЕДАКТИРУЙТЕ backend/.env перед запуском!"
fi

npm run dev &
BACKEND_PID=$!
echo "✅ Backend запущен (PID: $BACKEND_PID)"

# Frontend
echo ""
echo "🎨 Запуск Frontend..."
cd ../frontend
if [ ! -d "node_modules" ]; then
    echo "📦 Установка зависимостей Frontend..."
    npm install
fi

if [ ! -f ".env" ]; then
    echo "📝 Создание .env файла из примера..."
    cp .env.example .env
fi

npm run dev &
FRONTEND_PID=$!
echo "✅ Frontend запущен (PID: $FRONTEND_PID)"

echo ""
echo "🚀 ОБА С��РВЕРА ЗАПУЩЕНЫ!"
echo "========================"
echo "Frontend: http://localhost:5173"
echo "Backend:  http://localhost:5000"
echo ""
echo "Нажмите Ctrl+C для остановки..."

# Ждём сигнала завершения
wait