import { Request, Response, NextFunction } from 'express';
import AuthService from '../services/authService';

declare global {
  namespace Express {
    interface Request {
      userId?: string;
    }
  }
}

export const authenticateToken = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Токен не предоставлен' });
  }

  try {
    const userId = AuthService.verifyToken(token);
    req.userId = userId;
    next();
  } catch (error) {
    res.status(403).json({ error: 'Невалидный или истёкший токен' });
  }
};