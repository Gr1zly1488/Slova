import { QUESTIONS } from '../data/questions';
import { Question } from '../models/Question';

async function seedQuestions() {
  try {
    const count = await Question.countDocuments();
    if (count > 0) {
      console.log('✅ Вопросы уже в БД');
      return;
    }

    // Преобразуем с добавлением вариантов ответов
    const questionsWithAnswers = QUESTIONS.map((q) => ({
      text: q.text,
      category: q.category,
      difficulty: q.category,
      explanation: q.hint,
      answers: [
        { text: q.answer, isCorrect: true },
        { text: 'неправильный ответ 1', isCorrect: false },
        { text: 'неправильный ответ 2', isCorrect: false },
        { text: 'неправильный ответ 3', isCorrect: false },
      ].sort(() => Math.random() - 0.5), // Перемешиваем ответы
    }));

    await Question.insertMany(questionsWithAnswers);
    console.log('✅ Добавлено 32 вопроса в БД');
  } catch (error) {
    console.error('❌ Ошибка при добавлении вопросов:', error);
  }
}

export default seedQuestions;