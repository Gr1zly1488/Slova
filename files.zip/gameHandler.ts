// ⚠️ ДЕМО-ВЕРСИЯ - ТОЛЬКО ДЛЯ ОБУЧЕНИЯ
// Socket.io обработчики для игры "Слова"

import { Socket, Server as SocketIOServer } from 'socket.io';
import { User, IUser } from '../models/User';
import { Game, IGame } from '../models/Game';
import { Question } from '../models/Question';
import { Match } from '../models/Match';
import { Types } from 'mongoose';
import GameService from '../services/gameService';
import MatchmakingService from '../services/matchmakingService';

// Интерфейсы для типизации
interface GameRoom {
  gameId: string;
  player1: {
    id: string;
    username: string;
    score: number;
    socketId: string;
  };
  player2: {
    id: string;
    username: string;
    score: number;
    socketId: string;
  };
  currentRound: number;
  questionId?: string;
  timerInterval?: NodeJS.Timeout;
  answers: Map<string, number>; // socketId -> answerIndex
  responseTime: Map<string, number>; // socketId -> ms
}

// Хранилища комнат и очередей
const gameRooms = new Map<string, GameRoom>();
const matchmakingQueues = new Map<number, string[]>(); // betAmount -> [socketIds]
const userSockets = new Map<string, string>(); // userId -> socketId
const socketUsers = new Map<string, string>(); // socketId -> userId

export class GameHandler {
  /**
   * Регистрация всех Socket.io обработчиков
   */
  static registerHandlers(io: SocketIOServer, socket: Socket) {
    console.log(`📡 Новое подключение: ${socket.id}`);

    // При подключении
    socket.on('user:register', (userId: string) => {
      userSockets.set(userId, socket.id);
      socketUsers.set(socket.id, userId);
      console.log(`👤 Пользователь зарегистрирован: ${userId} (${socket.id})`);
    });

    // Matchmaking события
    socket.on('matchmaking:join', (betAmount: number) =>
      GameHandler.joinMatchmaking(io, socket, betAmount)
    );
    socket.on('matchmaking:cancel', () =>
      GameHandler.cancelMatchmaking(socket)
    );

    // Игровые события
    socket.on('game:start-round', () =>
      GameHandler.startRound(io, socket)
    );
    socket.on('game:submit-answer', (answer: number, responseTime: number) =>
      GameHandler.submitAnswer(io, socket, answer, responseTime)
    );
    socket.on('game:next-round', () =>
      GameHandler.nextRound(io, socket)
    );
    socket.on('game:end', () =>
      GameHandler.endGame(io, socket)
    );

    // При отключении
    socket.on('disconnect', () =>
      GameHandler.handleDisconnect(io, socket)
    );
  }

  // ============ MATCHMAKING ============

  /**
   * Пользователь присоединяется к очереди matchmaking
   * socket.emit('matchmaking:join', betAmount)
   */
  static async joinMatchmaking(
    io: SocketIOServer,
    socket: Socket,
    betAmount: number
  ) {
    try {
      console.log(`🎮 Joinning matchmaking: betAmount=${betAmount}`);

      const userId = socketUsers.get(socket.id);
      if (!userId) {
        socket.emit('error', { message: 'Не авторизован' });
        return;
      }

      // Валидация ставки
      if (![10, 20, 50].includes(betAmount)) {
        socket.emit('error', {
          message: 'Неверная сумма ставки. Доступные: 10, 20, 50 USD',
        });
        return;
      }

      // Проверяем баланс пользователя
      const user = await User.findById(userId);
      if (!user || user.balance < betAmount) {
        socket.emit('error', {
          message: 'Недостаточно средств на балансе',
        });
        return;
      }

      // Добавляем в очередь
      if (!matchmakingQueues.has(betAmount)) {
        matchmakingQueues.set(betAmount, []);
      }

      const queue = matchmakingQueues.get(betAmount)!;
      queue.push(socket.id);

      // Уведомляем клиента
      socket.emit('matchmaking:joined', {
        betAmount,
        position: queue.length,
        message: `Вы в очереди на поиск игрока (позиция: ${queue.length})`,
      });

      console.log(`⏳ Очередь для ставки ${betAmount}: ${queue.length} игроков`);

      // Проверяем, есть ли пара для матча
      if (queue.length >= 2) {
        await GameHandler.createMatch(io, betAmount);
      }
    } catch (error: any) {
      console.error('❌ Ошибка при присоединении к matchmaking:', error);
      socket.emit('error', { message: error.message });
    }
  }

  /**
   * Отмена поиска в matchmaking
   */
  static cancelMatchmaking(socket: Socket) {
    try {
      console.log(`❌ Отмена matchmaking: ${socket.id}`);

      // Находим и удаляем из всех очередей
      for (const [betAmount, queue] of matchmakingQueues.entries()) {
        const index = queue.indexOf(socket.id);
        if (index !== -1) {
          queue.splice(index, 1);
          socket.emit('matchmaking:cancelled', { betAmount });
          console.log(`⏳ Удалено из очереди ${betAmount}`);
        }
      }
    } catch (error: any) {
      console.error('❌ Ошибка при отмене matchmaking:', error);
    }
  }

  /**
   * Создаёт матч между двумя игроками
   */
  private static async createMatch(
    io: SocketIOServer,
    betAmount: number
  ) {
    try {
      const queue = matchmakingQueues.get(betAmount);
      if (!queue || queue.length < 2) return;

      // Извлекаем двух игроков из очереди
      const player1SocketId = queue.shift()!;
      const player2SocketId = queue.shift()!;

      const player1UserId = socketUsers.get(player1SocketId);
      const player2UserId = socketUsers.get(player2SocketId);

      if (!player1UserId || !player2UserId) {
        console.error('❌ Не удалось найти userId для игроков');
        return;
      }

      // Получаем данные пользователей
      const player1 = await User.findById(player1UserId);
      const player2 = await User.findById(player2UserId);

      if (!player1 || !player2) {
        console.error('❌ Пользователи не найдены');
        return;
      }

      // Создаём Game в БД
      const expiresAt = new Date();
      expiresAt.setMinutes(expiresAt.getMinutes() + 30); // 30 минут на игру

      const game = new Game({
        player1Id: new Types.ObjectId(player1UserId),
        player2Id: new Types.ObjectId(player2UserId),
        betAmount,
        status: 'active',
        expiresAt,
      });

      await game.save();

      // Создаём Game Room в памяти
      const gameRoom: GameRoom = {
        gameId: game._id.toString(),
        player1: {
          id: player1UserId,
          username: player1.username,
          score: 0,
          socketId: player1SocketId,
        },
        player2: {
          id: player2UserId,
          username: player2.username,
          score: 0,
          socketId: player2SocketId,
        },
        currentRound: 0,
        answers: new Map(),
        responseTime: new Map(),
      };

      gameRooms.set(game._id.toString(), gameRoom);

      // Создаём Socket.io комнату
      const gameRoomName = `game:${game._id}`;
      const player1Socket = io.sockets.sockets.get(player1SocketId);
      const player2Socket = io.sockets.sockets.get(player2SocketId);

      if (player1Socket) player1Socket.join(gameRoomName);
      if (player2Socket) player2Socket.join(gameRoomName);

      console.log(`✅ Матч создан: ${player1.username} vs ${player2.username}`);

      // Отправляем данные обоим игрокам
      io.to(gameRoomName).emit('game:created', {
        gameId: game._id,
        player1: {
          username: player1.username,
          avatar: player1.username.charAt(0).toUpperCase(),
        },
        player2: {
          username: player2.username,
          avatar: player2.username.charAt(0).toUpperCase(),
        },
        betAmount,
        message: `Матч начинается! ${player1.username} vs ${player2.username}`,
      });

      // Запускаем первый раунд через 3 секунды
      setTimeout(() => {
        GameHandler.startRound(io, player1Socket!);
      }, 3000);
    } catch (error: any) {
      console.error('❌ Ошибка при создании матча:', error);
    }
  }

  // ============ ИГРОВОЙ ПРОЦЕСС ============

  /**
   * Начинает раунд: выбирает вопрос и отправляет его с таймером 30 сек
   */
  static async startRound(io: SocketIOServer, socket: Socket) {
    try {
      console.log(`🎯 Начало раунда`);

      const userId = socketUsers.get(socket.id);
      if (!userId) return;

      // Находим комнату игрока
      const gameRoom = Array.from(gameRooms.values()).find(
        (room) =>
          room.player1.socketId === socket.id ||
          room.player2.socketId === socket.id
      );

      if (!gameRoom) {
        socket.emit('error', { message: 'Комната не найдена' });
        return;
      }

      // Проверяем количество раундов
      if (gameRoom.currentRound >= 5) {
        GameHandler.endGame(io, socket);
        return;
      }

      // Получаем случайный вопрос
      const question = await GameService.getRandomQuestion();
      if (!question) {
        socket.emit('error', { message: 'Вопросы не найдены' });
        return;
      }

      gameRoom.questionId = question._id.toString();
      gameRoom.answers.clear();
      gameRoom.responseTime.clear();

      // Отправляем вопрос обоим игрокам
      const gameRoomName = `game:${gameRoom.gameId}`;
      io.to(gameRoomName).emit('game:round-started', {
        roundNumber: gameRoom.currentRound + 1,
        question: question.toGameJSON(),
        timerSeconds: 30,
        message: `Раунд ${gameRoom.currentRound + 1} из 5. У вас есть 30 секунд!`,
      });

      // Запускаем таймер 30 секунд
      let timeLeft = 30;

      if (gameRoom.timerInterval) {
        clearInterval(gameRoom.timerInterval);
      }

      gameRoom.timerInterval = setInterval(() => {
        timeLeft--;

        // Отправляем обновление таймера
        io.to(gameRoomName).emit('game:timer-tick', {
          timeLeft,
        });

        // ��сли время истекло
        if (timeLeft <= 0) {
          clearInterval(gameRoom.timerInterval);

          // Определяем победителя раунда
          GameHandler.finishRound(io, gameRoom);
        }
      }, 1000);

      console.log(`⏱️ Таймер запущен для раунда ${gameRoom.currentRound + 1}`);
    } catch (error: any) {
      console.error('❌ Ошибка при начале раунда:', error);
      socket.emit('error', { message: error.message });
    }
  }

  /**
   * Игрок отправляет ответ
   */
  static async submitAnswer(
    io: SocketIOServer,
    socket: Socket,
    answerIndex: number,
    responseTime: number
  ) {
    try {
      console.log(
        `📝 Ответ получен: answerIndex=${answerIndex}, responseTime=${responseTime}ms`
      );

      // Находим комнату игрока
      const gameRoom = Array.from(gameRooms.values()).find(
        (room) =>
          room.player1.socketId === socket.id ||
          room.player2.socketId === socket.id
      );

      if (!gameRoom) {
        socket.emit('error', { message: 'Комната не найдена' });
        return;
      }

      // Сохраняем ответ
      gameRoom.answers.set(socket.id, answerIndex);
      gameRoom.responseTime.set(socket.id, responseTime);

      // Определяем имя игрока
      const isPlayer1 = gameRoom.player1.socketId === socket.id;
      const playerName = isPlayer1
        ? gameRoom.player1.username
        : gameRoom.player2.username;

      console.log(`✅ Ответ ${playerName}: индекс ${answerIndex}`);

      // Отправляем уведомление об ответе
      const gameRoomName = `game:${gameRoom.gameId}`;
      io.to(gameRoomName).emit('game:player-answered', {
        playerName,
        message: `${playerName} ответил!`,
      });

      // Если оба игрока ответили, финишируем раунд
      if (gameRoom.answers.size >= 2) {
        clearInterval(gameRoom.timerInterval);
        GameHandler.finishRound(io, gameRoom);
      }
    } catch (error: any) {
      console.error('❌ Ошибка при отправке ответа:', error);
      socket.emit('error', { message: error.message });
    }
  }

  /**
   * Завершает раунд: проверяет ответы, определяет победителя
   */
  private static async finishRound(io: SocketIOServer, gameRoom: GameRoom) {
    try {
      console.log(`🏁 Завершение раунда ${gameRoom.currentRound + 1}`);

      const gameRoomName = `game:${gameRoom.gameId}`;

      // Получаем вопрос
      if (!gameRoom.questionId) {
        io.to(gameRoomName).emit('error', { message: 'Вопрос не найден' });
        return;
      }

      const question = await Question.findById(gameRoom.questionId);
      if (!question) {
        io.to(gameRoomName).emit('error', { message: 'Вопрос не найден' });
        return;
      }

      const correctAnswerIndex = question.getCorrectAnswerIndex();

      // Проверяем ответы
      const player1Answer = gameRoom.answers.get(gameRoom.player1.socketId);
      const player2Answer = gameRoom.answers.get(gameRoom.player2.socketId);

      const player1ResponseTime =
        gameRoom.responseTime.get(gameRoom.player1.socketId) || 30000;
      const player2ResponseTime =
        gameRoom.responseTime.get(gameRoom.player2.socketId) || 30000;

      // Определяем победителя раунда
      let roundWinner: 'player1' | 'player2' | 'tie' | null = null;

      if (
        player1Answer === correctAnswerIndex &&
        player2Answer !== correctAnswerIndex
      ) {
        roundWinner = 'player1';
        gameRoom.player1.score += 1;
      } else if (
        player2Answer === correctAnswerIndex &&
        player1Answer !== correctAnswerIndex
      ) {
        roundWinner = 'player2';
        gameRoom.player2.score += 1;
      } else if (
        player1Answer === correctAnswerIndex &&
        player2Answer === correctAnswerIndex
      ) {
        // Оба ответили правильно - быстрее выигрывает
        if (player1ResponseTime < player2ResponseTime) {
          roundWinner = 'player1';
          gameRoom.player1.score += 1;
        } else {
          roundWinner = 'player2';
          gameRoom.player2.score += 1;
        }
      }

      // Сохраняем раунд в БД
      const game = await Game.findById(gameRoom.gameId);
      if (game) {
        game.rounds.push({
          questionId: new Types.ObjectId(gameRoom.questionId),
          player1Answer: player1Answer ?? null,
          player2Answer: player2Answer ?? null,
          player1ResponseTime,
          player2ResponseTime,
          winner: roundWinner,
          createdAt: new Date(),
        } as any);

        game.player1Score = gameRoom.player1.score;
        game.player2Score = gameRoom.player2.score;
        game.currentRoundIndex = gameRoom.currentRound + 1;
        await game.save();
      }

      // Отправляем результат раунда
      io.to(gameRoomName).emit('game:round-finished', {
        roundNumber: gameRoom.currentRound + 1,
        correctAnswerIndex,
        winner: roundWinner,
        player1Answer,
        player2Answer,
        player1ResponseTime: `${(player1ResponseTime / 1000).toFixed(2)}s`,
        player2ResponseTime: `${(player2ResponseTime / 1000).toFixed(2)}s`,
        scores: {
          player1: gameRoom.player1.score,
          player2: gameRoom.player2.score,
        },
        message:
          roundWinner === 'player1'
            ? `${gameRoom.player1.username} выиграл раунд!`
            : roundWinner === 'player2'
            ? `${gameRoom.player2.username} выиграл раунд!`
            : 'Ничья в раунде!',
      });

      gameRoom.currentRound += 1;
    } catch (error: any) {
      console.error('❌ Ошибка при завершении раунда:', error);
    }
  }

  /**
   * Переход к следующему раунду
   */
  static async nextRound(io: SocketIOServer, socket: Socket) {
    try {
      console.log(`⏭️ Переход к следующему раунду`);

      const gameRoom = Array.from(gameRooms.values()).find(
        (room) =>
          room.player1.socketId === socket.id ||
          room.player2.socketId === socket.id
      );

      if (!gameRoom) return;

      // Если это был последний раунд
      if (gameRoom.currentRound >= 5) {
        GameHandler.endGame(io, socket);
        return;
      }

      // Запускаем следующий раунд
      setTimeout(() => {
        GameHandler.startRound(io, socket);
      }, 2000); // 2 секунды на подготовку
    } catch (error: any) {
      console.error('❌ Ошибка при переходе к следующему раунду:', error);
    }
  }

  /**
   * Завершает игру: подсчитывает побед, переводит деньги
   */
  static async endGame(io: SocketIOServer, socket: Socket) {
    try {
      console.log(`🏆 Завершение игры`);

      const userId = socketUsers.get(socket.id);
      const gameRoom = Array.from(gameRooms.values()).find(
        (room) =>
          room.player1.socketId === socket.id ||
          room.player2.socketId === socket.id
      );

      if (!gameRoom) {
        socket.emit('error', { message: 'Комната не найдена' });
        return;
      }

      // Очищаем таймер
      if (gameRoom.timerInterval) {
        clearInterval(gameRoom.timerInterval);
      }

      const gameRoomName = `game:${gameRoom.gameId}`;

      // Получаем игру из БД
      const game = await Game.findById(gameRoom.gameId);
      if (!game) {
        io.to(gameRoomName).emit('error', { message: 'Игра не найдена' });
        return;
      }

      // Получаем пользователей
      const player1 = await User.findById(gameRoom.player1.id);
      const player2 = await User.findById(gameRoom.player2.id);

      if (!player1 || !player2) {
        io.to(gameRoomName).emit('error', { message: 'Пользователи не найдены' });
        return;
      }

      // Определяем победителя
      let winnerId: string | null = null;
      let winnerName = '';

      if (gameRoom.player1.score > gameRoom.player2.score) {
        winnerId = gameRoom.player1.id;
        winnerName = gameRoom.player1.username;
      } else if (gameRoom.player2.score > gameRoom.player1.score) {
        winnerId = gameRoom.player2.id;
        winnerName = gameRoom.player2.username;
      }

      // Расчёт призовых денег (5% комиссия платформы)
      const totalPool = gameRoom.player1.score === gameRoom.player2.score ?
        gameRoom.player1.score === 0 ? 0 : gameRoom.player1.score * gameRoom.player1.score :
        gameRoom.player1.score + gameRoom.player2.score;

      const betAmount = game.betAmount;
      const totalBet = betAmount * 2;
      const commissionPercent = 5;
      const commission = parseFloat((totalBet * (commissionPercent / 100)).toFixed(2));
      const prizeAmount = parseFloat((totalBet - commission).toFixed(2));

      // Обновляем баланс победителя
      if (winnerId) {
        if (winnerId === gameRoom.player1.id) {
          player1.balance += prizeAmount;
          player1.totalWins += 1;
          player2.totalLosses += 1;
        } else {
          player2.balance += prizeAmount;
          player2.totalWins += 1;
          player1.totalLosses += 1;
        }
      } else {
        // Ничья - каждый получает свою ставку назад
        player1.balance += betAmount;
        player2.balance += betAmount;
      }

      // Обновляем статистику
      player1.totalGamesPlayed += 1;
      player2.totalGamesPlayed += 1;

      await player1.save();
      await player2.save();

      // Обновляем Game в БД
      game.status = 'finished';
      if (winnerId) {
        game.winner = new Types.ObjectId(winnerId);
      }
      game.prizeMoney = winnerId ? prizeAmount : betAmount;
      game.platformCommission = winnerId ? commission : 0;
      await game.save();

      // Создаём Match (историю игры)
      const match = new Match({
        player1Id: new Types.ObjectId(gameRoom.player1.id),
        player2Id: new Types.ObjectId(gameRoom.player2.id),
        player1Username: gameRoom.player1.username,
        player2Username: gameRoom.player2.username,
        betAmount,
        winnerId: winnerId ? new Types.ObjectId(winnerId) : null,
        winnerUsername: winnerId ? winnerName : 'tie',
        player1Score: gameRoom.player1.score,
        player2Score: gameRoom.player2.score,
        prizeMoney: winnerId ? prizeAmount : betAmount,
        platformCommission: winnerId ? commission : 0,
        gameId: new Types.ObjectId(gameRoom.gameId),
        duration: 300, // 5 раундов * 60 секунд примерно
      });
      await match.save();

      console.log(`✅ Игра завершена. Победитель: ${winnerName || 'Ничья'}`);

      // Отправляем результат
      io.to(gameRoomName).emit('game:ended', {
        gameId: gameRoom.gameId,
        winner: winnerId ? winnerName : null,
        scores: {
          player1: gameRoom.player1.score,
          player2: gameRoom.player2.score,
        },
        prizeAmount: winnerId ? prizeAmount : betAmount,
        commission: winnerId ? commission : 0,
        newBalances: {
          player1: player1.balance,
          player2: player2.balance,
        },
        message: winnerId
          ? `🎉 ${winnerName} выиграл ${prizeAmount} USD!`
          : `🤝 Ничья! Каждый получает свою ставку назад`,
      });

      // Удаляем комнату после 5 секунд
      setTimeout(() => {
        gameRooms.delete(gameRoom.gameId);
        io.to(gameRoomName).emit('game:room-closed');
        console.log(`🗑️ Комната удалена: ${gameRoom.gameId}`);
      }, 5000);
    } catch (error: any) {
      console.error('❌ Ошибка при завершении игры:', error);
    }
  }

  // ============ УПРАВЛЕНИЕ СОЕДИНЕНИЯМИ ============

  /**
   * Обработка отключения игрока
   */
  static async handleDisconnect(io: SocketIOServer, socket: Socket) {
    try {
      console.log(`🔌 Отключение: ${socket.id}`);

      const userId = socketUsers.get(socket.id);

      // Удаляем из maps
      if (userId) {
        userSockets.delete(userId);
      }
      socketUsers.delete(socket.id);

      // Удаляем из matchmaking очередей
      GameHandler.cancelMatchmaking(socket);

      // Если игрок был в игре, отмечаем её как abandoned
      const gameRoom = Array.from(gameRooms.values()).find(
        (room) =>
          room.player1.socketId === socket.id ||
          room.player2.socketId === socket.id
      );

      if (gameRoom) {
        const game = await Game.findById(gameRoom.gameId);
        if (game) {
          game.status = 'abandoned';
          await game.save();
        }

        const gameRoomName = `game:${gameRoom.gameId}`;
        io.to(gameRoomName).emit('game:player-disconnected', {
          message: 'Противник отключился. Игра отменена.',
        });

        gameRooms.delete(gameRoom.gameId);
      }

      console.log(`✅ Очищено соединение: ${socket.id}`);
    } catch (error: any) {
      console.error('❌ Ошибка при обработке отключения:', error);
    }
  }
}