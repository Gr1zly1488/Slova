import { useEffect, useState } from 'react';
import { useAppSelector } from '../../store/store';

/**
 * Компонент истории игр пользователя
 */
export const GameHistory = () => {
  const { user } = useAppSelector((state) => state.auth);
  const [matches, setMatches] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // TODO: Загрузить историю игр с API
    setLoading(false);
  }, []);

  if (loading) {
    return (
      <div className="text-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-400 mx-auto"></div>
      </div>
    );
  }

  if (matches.length === 0) {
    return (
      <div className="text-center py-12 text-gray-400">
        <p className="text-lg">📭 История игр пуста</p>
        <p className="text-sm">Сыграйте свою первую игру!</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {matches.map((match) => {
        const isWin = match.winnerId === user?._id;

        return (
          <div
            key={match._id}
            className={`
              rounded-lg p-4 border
              ${isWin
                ? 'bg-green-900/20 border-green-700/50'
                : 'bg-red-900/20 border-red-700/50'
              }
            `}
          >
            <div className="flex justify-between items-start mb-2">
              <div>
                <p className="font-bold">
                  {match.player1Username} vs {match.player2Username}
                </p>
                <p className="text-sm text-gray-400">
                  {new Date(match.createdAt).toLocaleDateString('ru-RU')}
                </p>
              </div>
              <div className="text-right">
                <p className={`font-bold ${isWin ? 'text-green-400' : 'text-red-400'}`}>
                  {isWin ? '✅ Победа' : '❌ Поражение'}
                </p>
                <p className="text-sm text-gray-400">
                  {match.player1Score} : {match.player2Score}
                </p>
              </div>
            </div>

            {isWin && (
              <div className="pt-2 border-t border-green-700/30 text-green-400 text-sm">
                💰 +${match.prizeMoney.toFixed(2)}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};