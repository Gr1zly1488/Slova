import { configureStore, TypedUseSelectorHook, useDispatch, useSelector } from '@reduxjs/toolkit';
import authSlice from './slices/authSlice';
import gameSlice from './slices/gameSlice';
import walletSlice from './slices/walletSlice';
import matchmakingSlice from './slices/matchmakingSlice';
import uiSlice from './slices/uiSlice';
import notificationSlice from './slices/notificationSlice';

const store = configureStore({
  reducer: {
    auth: authSlice,
    game: gameSlice,
    wallet: walletSlice,
    matchmaking: matchmakingSlice,
    ui: uiSlice,
    notification: notificationSlice,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

// Типизированные хуки для использования в компонентах
export const useAppDispatch = () => useDispatch<AppDispatch>();
export const useAppSelector: TypedUseSelectorHook<RootState> = useSelector;

export default store;