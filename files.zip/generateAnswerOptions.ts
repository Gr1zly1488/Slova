// Генерирует 4 варианта ответов (правильный + 3 неправильных)

export const DISTRACTOR_ANSWERS: Record<string, string[]> = {
  'москва': ['санкт-петербург', 'казань', 'новосибирск'],
  'кислород': ['азот', 'водород', 'гелий'],
  'бетховен': ['моцарт', 'чайковский', 'баха'],
  'толстой': ['достоевский', 'пушкин', 'лермонтов'],
  '1945': ['1944', '1946', '1943'],
  'река': ['озеро', 'болото', 'море'],
  // ... и так далее
};

export function generateAnswerOptions(
  correctAnswer: string,
  distractors: string[] = []
): { text: string; isCorrect: boolean }[] {
  const options = [
    { text: correctAnswer, isCorrect: true },
    ...distractors.slice(0, 3).map((text) => ({
      text,
      isCorrect: false,
    })),
  ];

  // Перемешиваем ответы
  return options.sort(() => Math.random() - 0.5);
}