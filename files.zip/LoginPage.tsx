import { AuthGuard } from '../components/auth/AuthGuard';
import { LoginForm } from '../components/auth/LoginForm';

/**
 * Страница входа в аккаунт
 */
export const LoginPage = () => {
  return (
    <AuthGuard>
      <div className="space-y-4">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">🎮 Слова</h1>
          <p className="text-gray-400">Выиграй денежные призы в словесной дуэли</p>
        </div>

        <LoginForm />

        <p className="text-center text-gray-400 text-sm">
          Нет аккаунта?{' '}
          <a href="/register" className="text-blue-400 hover:text-blue-300">
            Зарегистрируйтесь
          </a>
        </p>
      </div>
    </AuthGuard>
  );
};

export default LoginPage;