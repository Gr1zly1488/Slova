import { Link, useNavigate } from 'react-router-dom';
import { useAppDispatch, useAppSelector } from '../../store/store';
import { logout } from '../../store/slices/authSlice';

/**
 * Навигационная панель (хедер)
 */
const NavBar = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const { user } = useAppSelector((state) => state.auth);

  const handleLogout = () => {
    dispatch(logout());
    navigate('/login');
  };

  return (
    <nav className="bg-slate-800 border-b border-slate-700 sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        {/* Логотип */}
        <Link to="/lobby" className="flex items-center space-x-2 text-white text-2xl font-bold hover:text-blue-400 transition">
          <span>🎮</span>
          <span>Слова</span>
        </Link>

        {/* Меню */}
        <div className="flex items-center space-x-6">
          <Link
            to="/lobby"
            className="text-gray-300 hover:text-white transition"
          >
            🏠 Лобби
          </Link>
          <Link
            to="/profile"
            className="text-gray-300 hover:text-white transition"
          >
            👤 Профиль
          </Link>
          <Link
            to="/wallet"
            className="text-gray-300 hover:text-white transition flex items-center space-x-1"
          >
            <span>💰</span>
            <span>{user?.balance.toFixed(2)} USD</span>
          </Link>

          {/* Кнопка выхода */}
          <button
            onClick={handleLogout}
            className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded transition"
          >
            🚪 Выход
          </button>
        </div>
      </div>
    </nav>
  );
};

export default NavBar;