// ⚠️ ДЕМО-ВЕРСИЯ - ТОЛЬКО ДЛЯ ОБУЧЕНИЯ
// Stripe интеграция для депозитов
// Реальное приложение требует: PCI compliance, аудита, лицензирования

import { Request, Response } from 'express';
import Stripe from 'stripe';
import { User } from '../models/User';
import { Payment } from '../models/Payment';
import { Types } from 'mongoose';

// Инициализируем Stripe с секретным ключом
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-04-10',
});

class PaymentController {
  /**
   * Создаёт Stripe Checkout сессию для депозита
   * POST /api/v1/payment/create-checkout
   */
  static async createCheckoutSession(req: Request, res: Response) {
    try {
      const { amount } = req.body;
      const userId = req.userId;

      // Валидация входных данных
      if (!amount || amount < 10 || amount > 1000) {
        return res.status(400).json({
          error: 'Сумма должна быть от 10 до 1000 USD',
        });
      }

      if (!userId) {
        return res.status(401).json({ error: 'Не авторизован' });
      }

      // Получаем пользователя
      const user = await User.findById(userId);
      if (!user) {
        return res.status(404).json({ error: 'Пользователь не найден' });
      }

      // Создаём Payment запись в БД
      const payment = new Payment({
        userId: new Types.ObjectId(userId),
        amount,
        status: 'pending',
        type: 'deposit',
      });
      await payment.save();

      // Создаём Stripe Checkout сессию
      const session = await stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        mode: 'payment',
        line_items: [
          {
            price_data: {
              currency: 'usd',
              product_data: {
                name: `Пополнение баланса - ${amount} USD`,
                description: `Игра "Слова" - Депозит`,
                images: [
                  'https://via.placeholder.com/300x300?text=Slova+Game',
                ],
              },
              unit_amount: Math.round(amount * 100), // Stripe работает в центах
            },
            quantity: 1,
          },
        ],
        customer_email: user.email,
        client_reference_id: payment._id.toString(), // Связываем с Payment в БД
        success_url: `${process.env.CLIENT_URL}/payment/success?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${process.env.CLIENT_URL}/payment/cancel`,
        metadata: {
          userId: userId,
          paymentId: payment._id.toString(),
          amount: amount.toString(),
        },
      });

      // Сохраняем sessionId в Payment
      payment.stripeSessionId = session.id;
      await payment.save();

      res.json({
        success: true,
        sessionId: session.id,
        checkoutUrl: session.url,
      });
    } catch (error: any) {
      console.error('❌ Ошибка при создании Checkout сессии:', error);
      res.status(500).json({
        error: error.message || 'Ошибка при создании платежа',
      });
    }
  }

  /**
   * Проверяет статус платежа по sessionId
   * GET /api/v1/payment/session-status/:sessionId
   */
  static async getSessionStatus(req: Request, res: Response) {
    try {
      const { sessionId } = req.params;

      if (!sessionId) {
        return res.status(400).json({ error: 'Session ID не предоставлен' });
      }

      // Получаем сессию из Stripe
      const session = await stripe.checkout.sessions.retrieve(sessionId);

      res.json({
        status: session.payment_status, // 'paid', 'unpaid', 'no_payment_required'
        paymentStatus: session.payment_status,
        customer_email: session.customer_email,
        amount: (session.amount_total || 0) / 100, // Конвертируем из центов
      });
    } catch (error: any) {
      console.error('❌ Ошибка при получении статуса сессии:', error);
      res.status(500).json({
        error: error.message || 'Ошибка при получении статуса',
      });
    }
  }

  /**
   * Webhook handler для успешных платежей от Stripe
   * POST /api/v1/payment/webhook
   * ⚠️ ВАЖНО: Этот маршрут не требует аутентификации!
   */
  static async handleWebhook(req: Request, res: Response) {
    try {
      const sig = req.headers['stripe-signature'] as string;
      const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET!;

      if (!sig || !webhookSecret) {
        return res.status(400).json({
          error: 'Webhook signature или secret не найдены',
        });
      }

      // Верифицируем подпись webhook'а
      let event: Stripe.Event;
      try {
        event = stripe.webhooks.constructEvent(
          req.body,
          sig,
          webhookSecret
        );
      } catch (err: any) {
        console.error('❌ Ошибка при верификации webhook подписи:', err);
        return res.status(400).json({
          error: `Webhook Error: ${err.message}`,
        });
      }

      console.log(`📨 Webhook event получен: ${event.type}`);

      // Обрабатываем разные типы событий
      switch (event.type) {
        case 'checkout.session.completed':
          await PaymentController.handleCheckoutSessionCompleted(
            event.data.object as Stripe.Checkout.Session
          );
          break;

        case 'charge.refunded':
          await PaymentController.handleChargeRefunded(
            event.data.object as Stripe.Charge
          );
          break;

        case 'charge.failed':
          console.error('❌ Платёж не прошёл:', event.data.object);
          break;

        default:
          console.log(`ℹ️ Неизвестный event type: ${event.type}`);
      }

      // Отправляем подтверждение Stripe
      res.json({ received: true });
    } catch (error: any) {
      console.error('❌ Ошибка в webhook handler:', error);
      res.status(500).json({
        error: error.message || 'Ошибка при обработке webhook',
      });
    }
  }

  /**
   * Обработчик успешной Checkout сессии
   * Пополняет баланс пользователя
   */
  private static async handleCheckoutSessionCompleted(
    session: Stripe.Checkout.Session
  ) {
    try {
      console.log('✅ Checkout сессия завершена:', session.id);

      // Получаем metadata
      const userId = session.metadata?.userId;
      const paymentId = session.metadata?.paymentId;
      const amount = parseFloat(session.metadata?.amount || '0');

      if (!userId || !paymentId) {
        console.error('❌ Отсутствуют необходимые метаданные в session');
        return;
      }

      // Получаем пользователя
      const user = await User.findById(userId);
      if (!user) {
        console.error(`❌ Пользователь с ID ${userId} не найден`);
        return;
      }

      // Получаем платёж
      const payment = await Payment.findById(paymentId);
      if (!payment) {
        console.error(`❌ Платёж с ID ${paymentId} не найден`);
        return;
      }

      // Проверяем, что платёж успешен
      if (session.payment_status !== 'paid') {
        console.error('❌ Платёж не был успешно завершен');
        payment.status = 'failed';
        await payment.save();
        return;
      }

      // Пополняем баланс пользователя
      user.balance += amount;
      await user.save();

      // Обновляем статус платежа
      payment.status = 'completed';
      payment.stripeSessionId = session.id;
      payment.stripePaymentIntentId = session.payment_intent as string;
      await payment.save();

      console.log(
        `✅ Баланс пополнен: ${user.email} += ${amount} USD (новый баланс: ${user.balance})`
      );
    } catch (error: any) {
      console.error(
        '❌ Ошибка при обработке успешной checkout сессии:',
        error
      );
    }
  }

  /**
   * Обработчик возврата средств
   */
  private static async handleChargeRefunded(charge: Stripe.Charge) {
    try {
      console.log('⚠️ Платёж возвращен:', charge.id);

      // Находим платёж по Stripe charge ID
      const payment = await Payment.findOne({
        stripeChargeId: charge.id,
      });

      if (!payment) {
        console.error(`⚠️ Платёж для charge ${charge.id} не найден`);
        return;
      }

      // Вычитаем средства из баланса пользователя
      const user = await User.findById(payment.userId);
      if (user) {
        user.balance = Math.max(0, user.balance - payment.amount);
        await user.save();
        console.log(`⚠️ Баланс уменьшен: ${user.email} -= ${payment.amount} USD`);
      }

      // Обновляем статус платежа
      payment.status = 'refunded';
      await payment.save();
    } catch (error: any) {
      console.error('❌ Ошибка при обработке возврата платежа:', error);
    }
  }

  /**
   * Получает историю транзакций пользователя
   * GET /api/v1/payment/history
   */
  static async getPaymentHistory(req: Request, res: Response) {
    try {
      const userId = req.userId;

      if (!userId) {
        return res.status(401).json({ error: 'Не авторизован' });
      }

      const payments = await Payment.find({
        userId: new Types.ObjectId(userId),
      })
        .sort({ createdAt: -1 })
        .limit(50);

      res.json({
        success: true,
        payments: payments.map((p) => ({
          _id: p._id,
          amount: p.amount,
          status: p.status,
          type: p.type,
          createdAt: p.createdAt,
        })),
      });
    } catch (error: any) {
      console.error('❌ Ошибка при получении истории платежей:', error);
      res.status(500).json({
        error: error.message || 'Ошибка при получении истории',
      });
    }
  }
}

export default PaymentController;