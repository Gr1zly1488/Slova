import { createSlice, PayloadAction } from '@reduxjs/toolkit';

export interface Notification {
  id?: string;
  type: 'success' | 'error' | 'info' | 'warning';
  message: string;
  duration?: number;
}

interface NotificationState {
  notifications: Notification[];
}

const initialState: NotificationState = {
  notifications: [],
};

const notificationSlice = createSlice({
  name: 'notification',
  initialState,
  reducers: {
    showNotification: (state, action: PayloadAction<Notification>) => {
      const id = Date.now().toString();
      state.notifications.push({ ...action.payload, id });

      // Автоматически удалять уведомление через 5 секунд
      setTimeout(() => {
        state.notifications = state.notifications.filter((n) => n.id !== id);
      }, action.payload.duration || 5000);
    },
    removeNotification: (state, action: PayloadAction<string>) => {
      state.notifications = state.notifications.filter(
        (n) => n.id !== action.payload
      );
    },
  },
});

export const { showNotification, removeNotification } = notificationSlice.actions;
export default notificationSlice.reducer;