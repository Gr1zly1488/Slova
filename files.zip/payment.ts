import { Router, Request, Response } from 'express';
import PaymentController from '../controllers/paymentController';
import { authenticateToken } from '../middleware/authenticate';
import express from 'express';

const router = Router();

/**
 * ⚠️ ВАЖНО: Webhook маршрут должен б��ть ПЕРЕД bodyParser middleware!
 * Он использует raw body для верификации подписи Stripe
 */

/**
 * POST /api/v1/payment/webhook
 * Webhook для Stripe событий
 * ❌ НЕ требует аутентификацию
 */
router.post(
  '/webhook',
  express.raw({ type: 'application/json' }),
  PaymentController.handleWebhook
);

/**
 * POST /api/v1/payment/create-checkout
 * Создаёт Stripe Checkout сессию
 * ✅ Требует аутентификацию
 */
router.post(
  '/create-checkout',
  authenticateToken,
  PaymentController.createCheckoutSession
);

/**
 * GET /api/v1/payment/session-status/:sessionId
 * Проверяет статус платежа
 */
router.get(
  '/session-status/:sessionId',
  PaymentController.getSessionStatus
);

/**
 * GET /api/v1/payment/history
 * Получает историю платежей пользователя
 * ✅ Требует аутентификацию
 */
router.get(
  '/history',
  authenticateToken,
  PaymentController.getPaymentHistory
);

export default router;