interface RoundResultProps {
  result: any;
  isCurrentPlayerWinner: boolean;
  onContinue: () => void;
  isFinalRound: boolean;
}

/**
 * Компонент результата раунда
 */
export const RoundResult = ({
  result,
  isCurrentPlayerWinner,
  onContinue,
  isFinalRound,
}: RoundResultProps) => {
  return (
    <div className="w-full max-w-2xl space-y-8">
      {/* Результат */}
      <div className="text-center space-y-6">
        <div className="text-6xl">
          {result.winner === 'tie' ? '🤝' : isCurrentPlayerWinner ? '🎉' : '❌'}
        </div>

        <div>
          <h2 className="text-3xl font-bold mb-2">
            {result.winner === 'tie'
              ? 'Ничья!'
              : isCurrentPlayerWinner
              ? 'Вы выиграли раунд!'
              : 'Противник выиграл'}
          </h2>
          <p className="text-gray-400">{result.message}</p>
        </div>

        {/* Информация о правильном ответе */}
        <div className="bg-green-900/30 border border-green-700/50 rounded-lg p-4">
          <p className="text-sm text-gray-400 mb-2">Правильный ответ:</p>
          <p className="font-bold text-green-400">
            {['A', 'B', 'В', 'Г'][result.correctAnswerIndex]}
          </p>
        </div>

        {/* Время ответа */}
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="bg-slate-800/50 rounded-lg p-3">
            <p className="text-gray-400">Ваше время</p>
            <p className="font-bold text-white">{result.player1ResponseTime}</p>
          </div>
          <div className="bg-slate-800/50 rounded-lg p-3">
            <p className="text-gray-400">Время противника</p>
            <p className="font-bold text-white">{result.player2ResponseTime}</p>
          </div>
        </div>

        {/* Счёт */}
        <div className="text-2xl font-bold">
          <span className={result.scores.player1 > result.scores.player2 ? 'text-green-400' : 'text-gray-400'}>
            {result.scores.player1}
          </span>
          <span className="text-gray-400 mx-2">:</span>
          <span className={result.scores.player2 > result.scores.player1 ? 'text-pink-400' : 'text-gray-400'}>
            {result.scores.player2}
          </span>
        </div>
      </div>

      {/* Кнопка продолжения */}
      <button
        onClick={onContinue}
        className="w-full py-4 px-6 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 rounded-xl font-bold text-lg transition transform active:scale-95"
      >
        {isFinalRound ? '🏆 Финальный результат' : '⏭️ Следующий раунд'}
      </button>
    </div>
  );
};