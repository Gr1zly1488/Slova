interface GameFinishedProps {
  result: any;
  isWinner: boolean;
  onBackToLobby: () => void;
}

/**
 * Компонент конца игры
 */
export const GameFinished = ({
  result,
  isWinner,
  onBackToLobby,
}: GameFinishedProps) => {
  return (
    <div className="w-full max-w-2xl space-y-8">
      {/* Результат */}
      <div className="text-center space-y-6">
        <div className="text-7xl animate-bounce">
          {isWinner ? '🏆' : '🤝'}
        </div>

        <div>
          <h1 className="text-4xl font-black mb-2">
            {isWinner ? 'Вы выиграли!' : 'Игра завершена'}
          </h1>
          <p className="text-xl text-gray-300">{result.message}</p>
        </div>

        {/* Финальный счёт */}
        <div className="bg-gradient-to-r from-slate-800 to-slate-700 rounded-2xl p-8 border border-slate-600">
          <p className="text-sm text-gray-400 mb-4">Финальный счёт</p>
          <div className="text-5xl font-black">
            <span className={result.scores.player1 > result.scores.player2 ? 'text-green-400' : 'text-gray-400'}>
              {result.scores.player1}
            </span>
            <span className="text-gray-500 mx-4">:</span>
            <span className={result.scores.player2 > result.scores.player1 ? 'text-pink-400' : 'text-gray-400'}>
              {result.scores.player2}
            </span>
          </div>
        </div>

        {/* Призовые деньги */}
        {isWinner && (
          <div className="bg-gradient-to-r from-yellow-900/30 to-orange-900/30 border border-yellow-700/50 rounded-2xl p-6">
            <p className="text-sm text-gray-400 mb-2">Выигрыш</p>
            <div className="text-4xl font-black text-yellow-400">
              +${result.prizeAmount.toFixed(2)}
            </div>
            {result.commission > 0 && (
              <p className="text-xs text-gray-400 mt-3">
                Комиссия платформы: ${result.commission.toFixed(2)}
              </p>
            )}
          </div>
        )}

        {/* Новый баланс */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-slate-800/50 rounded-lg p-4">
            <p className="text-xs text-gray-400 mb-2">Ваш новый баланс</p>
            <p className="text-2xl font-bold text-blue-400">
              ${result.newBalances.player1.toFixed(2)}
            </p>
          </div>
          <div className="bg-slate-800/50 rounded-lg p-4">
            <p className="text-xs text-gray-400 mb-2">Баланс противника</p>
            <p className="text-2xl font-bold text-pink-400">
              ${result.newBalances.player2.toFixed(2)}
            </p>
          </div>
        </div>
      </div>

      {/* Кнопки действий */}
      <div className="space-y-3">
        <button
          onClick={onBackToLobby}
          className="w-full py-4 px-6 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 rounded-xl font-bold text-lg transition transform active:scale-95"
        >
          🏠 В лобби
        </button>

        <button
          onClick={onBackToLobby}
          className="w-full py-4 px-6 bg-slate-700 hover:bg-slate-600 rounded-xl font-bold text-lg transition"
        >
          📊 Посмотреть статистику
        </button>
      </div>

      {/* Disclaimer */}
      <div className="bg-yellow-900/20 border border-yellow-700/50 rounded-lg p-4 text-xs">
        <p className="text-yellow-300">
          ⚠️ <strong>Внимание:</strong> Это демо-версия. Выигрыши виртуальные.
        </p>
      </div>
    </div>
  );
};