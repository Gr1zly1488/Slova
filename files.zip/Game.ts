// ⚠️ ДЕМО-ВЕРСИЯ - ТОЛЬКО ДЛЯ ОБУЧЕНИЯ
// Модель активной игровой сессии

import { Schema, model, Document, Types } from 'mongoose';

// ============ TYPESCRIPT INTERFACES ============

export interface IRound {
  questionId: Types.ObjectId;
  player1Answer: number | null; // Индекс выбранного ответа
  player2Answer: number | null;
  player1ResponseTime: number; // В миллисекундах
  player2ResponseTime: number;
  winner: 'player1' | 'player2' | 'tie' | null;
  createdAt: Date;
}

export interface IGame extends Document {
  player1Id: Types.ObjectId;
  player2Id: Types.ObjectId;
  betAmount: number; // Ставка каждого игрока в USD
  status: 'waiting' | 'active' | 'finished' | 'abandoned';
  rounds: IRound[];
  currentRoundIndex: number;
  player1Score: number; // Количество выигранных раундов
  player2Score: number;
  winner: Types.ObjectId | null;
  prizeMoney: number; // Сумма для победителя (с учётом комиссии)
  platformCommission: number; // Комиссия платформы
  expiresAt: Date; // Время истечения игры
  createdAt: Date;
  updatedAt: Date;

  // Methods
  addRound(round: IRound): Promise<void>;
  finishGame(): Promise<void>;
  calculateWinner(): Types.ObjectId | null;
}

// ============ MONGOOSE SCHEMA ============

const roundSchema = new Schema<IRound>(
  {
    questionId: {
      type: Schema.Types.ObjectId,
      ref: 'Question',
      required: true,
    },

    player1Answer: {
      type: Number,
      default: null,
      min: -1,
      max: 3,
    },

    player2Answer: {
      type: Number,
      default: null,
      min: -1,
      max: 3,
    },

    player1ResponseTime: {
      type: Number,
      default: 0,
      min: 0,
    },

    player2ResponseTime: {
      type: Number,
      default: 0,
      min: 0,
    },

    winner: {
      type: String,
      enum: ['player1', 'player2', 'tie', null],
      default: null,
    },

    createdAt: {
      type: Date,
      default: Date.now,
    },
  },
  { _id: false }
);

const gameSchema = new Schema<IGame>(
  {
    player1Id: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'ID первого игрока обязателен'],
      index: true,
    },

    player2Id: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'ID второго игрока обязателен'],
      index: true,
    },

    betAmount: {
      type: Number,
      required: [true, 'Ставка обязательна'],
      min: [10, 'Минимальная ставка 10 USD'],
      max: [50, 'Максимальная ставка 50 USD'],
    },

    status: {
      type: String,
      enum: ['waiting', 'active', 'finished', 'abandoned'],
      default: 'waiting',
      index: true,
    },

    rounds: {
      type: [roundSchema],
      required: true,
      default: [],
    },

    currentRoundIndex: {
      type: Number,
      required: true,
      default: 0,
      min: 0,
      max: 4,
    },

    player1Score: {
      type: Number,
      required: true,
      default: 0,
      min: 0,
      max: 5,
    },

    player2Score: {
      type: Number,
      required: true,
      default: 0,
      min: 0,
      max: 5,
    },

    winner: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },

    prizeMoney: {
      type: Number,
      default: 0,
      min: 0,
      set: (value: number) => parseFloat(value.toFixed(2)),
    },

    platformCommission: {
      type: Number,
      default: 0,
      min: 0,
      set: (value: number) => parseFloat(value.toFixed(2)),
    },

    expiresAt: {
      type: Date,
      required: true,
      index: { expireAfterSeconds: 0 }, // TTL индекс - автоматически удалит документ
    },
  },
  {
    timestamps: true,
    collection: 'games',
  }
);

// ============ ИНДЕКСЫ ДЛЯ ПРОИЗВОДИТЕЛЬНОСТИ ============
gameSchema.index({ player1Id: 1, status: 1 });
gameSchema.index({ player2Id: 1, status: 1 });
gameSchema.index({ status: 1, createdAt: -1 }); // Для поиска активных игр
gameSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 }); // TTL индекс

// ============ МЕТОДЫ СХЕМЫ ============

/**
 * Добавляет новый раунд к игре
 */
gameSchema.methods.addRound = async function (round: IRound): Promise<void> {
  this.rounds.push(round);

  // Обновляем скор
  if (round.winner === 'player1') {
    this.player1Score += 1;
  } else if (round.winner === 'player2') {
    this.player2Score += 1;
  }

  // Если это был последний раунд (5-й), заканчиваем игру
  if (this.currentRoundIndex >= 4) {
    await this.finishGame();
  } else {
    this.currentRoundIndex += 1;
    await this.save();
  }
};

/**
 * Завершает игру и определяет победителя
 */
gameSchema.methods.finishGame = async function (): Promise<void> {
  this.status = 'finished';

  const winnerId = this.calculateWinner();
  if (winnerId) {
    this.winner = winnerId;

    // Расчёт призовых денег (5% комиссия платформы)
    const totalPool = this.betAmount * 2; // Оба игрока поставили
    const commissionPercent = 5;
    this.platformCommission = parseFloat(
      (totalPool * (commissionPercent / 100)).toFixed(2)
    );
    this.prizeMoney = parseFloat(
      (totalPool - this.platformCommission).toFixed(2)
    );
  } else {
    // Ничья - каждый получает свою ставку назад
    this.prizeMoney = this.betAmount;
    this.platformCommission = 0;
  }

  await this.save();
};

/**
 * Определяет победителя игры
 * @returns ID победителя или null при ничьей
 */
gameSchema.methods.calculateWinner = function (): Types.ObjectId | null {
  if (this.player1Score > this.player2Score) {
    return this.player1Id;
  } else if (this.player2Score > this.player1Score) {
    return this.player2Id;
  }
  return null; // Ничья
};

// ============ EXPORT ============
export const Game = model<IGame>('Game', gameSchema);