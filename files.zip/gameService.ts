import { Game, IGame } from '../models/Game';
import { Question } from '../models/Question';
import { Types } from 'mongoose';

class GameService {
  // Создание новой игры
  static async createGame(
    player1Id: string,
    player2Id: string,
    betAmount: number
  ): Promise<IGame> {
    const expiresAt = new Date();
    expiresAt.setMinutes(expiresAt.getMinutes() + 30); // 30 минут на игру

    const game = new Game({
      player1Id: new Types.ObjectId(player1Id),
      player2Id: new Types.ObjectId(player2Id),
      betAmount,
      status: 'active',
      expiresAt,
    });

    await game.save();
    return game;
  }

  // Получение случайного вопроса
  static async getRandomQuestion() {
    const count = await Question.countDocuments();
    const random = Math.floor(Math.random() * count);
    return Question.findOne().skip(random);
  }

  // Завершение раунда
  static async finishRound(
    gameId: string,
    player1Answer: number,
    player2Answer: number,
    questionId: string
  ) {
    const game = await Game.findById(gameId);
    if (!game) throw new Error('Игра не найдена');

    const question = await Question.findById(questionId);
    if (!question) throw new Error('Вопрос не найден');

    const correctAnswerIndex = question.getCorrectAnswerIndex();

    let winner = null;
    if (player1Answer === correctAnswerIndex && player2Answer !== correctAnswerIndex) {
      winner = 'player1';
      game.player1Score += 1;
    } else if (player2Answer === correctAnswerIndex && player1Answer !== correctAnswerIndex) {
      winner = 'player2';
      game.player2Score += 1;
    }

    game.rounds.push({
      questionId: new Types.ObjectId(questionId),
      player1Answer: player1Answer !== -1 ? player1Answer : null,
      player2Answer: player2Answer !== -1 ? player2Answer : null,
      player1ResponseTime: 0,
      player2ResponseTime: 0,
      winner: winner,
      createdAt: new Date(),
    } as any);

    // Если 5 раундов завершены, заканчиваем игру
    if (game.currentRoundIndex >= 4) {
      await game.finishGame();
    } else {
      game.currentRoundIndex += 1;
      await game.save();
    }

    return game;
  }
}

export default GameService;