import { useEffect, useState } from 'react';
import io, { Socket } from 'socket.io-client';

/**
 * Hook для работы с Socket.io соединением
 */
export const useSocket = () => {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) return;

    // Создаём Socket.io соединение
    const newSocket = io(import.meta.env.VITE_API_URL || 'http://localhost:5000', {
      auth: {
        token,
      },
      transports: ['websocket', 'polling'],
    });

    // События подключения
    newSocket.on('connect', () => {
      console.log('✅ Socket.io подключено:', newSocket.id);
      setIsConnected(true);

      // Регистрируем пользователя
      const userId = localStorage.getItem('userId');
      if (userId) {
        newSocket.emit('user:register', userId);
      }
    });

    newSocket.on('disconnect', () => {
      console.log('❌ Socket.io отключено');
      setIsConnected(false);
    });

    setSocket(newSocket);

    return () => {
      newSocket.disconnect();
    };
  }, []);

  return { socket, isConnected };
};