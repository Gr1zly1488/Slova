// Сервис матчмейкинга (опционально для более сложной логики)

import { User } from '../models/User';
import { Types } from 'mongoose';

class MatchmakingService {
  /**
   * Находит подходящего оппонента по MMR
   */
  static async findOpponent(
    userId: string,
    mmr: number,
    maxDifference: number = 500
  ) {
    try {
      const opponent = await User.findOne({
        _id: { $ne: new Types.ObjectId(userId) },
        mmr: {
          $gte: mmr - maxDifference,
          $lte: mmr + maxDifference,
        },
      }).sort({ mmr: 1 });

      return opponent;
    } catch (error) {
      console.error('❌ Ошибка при поиске оппонента:', error);
      return null;
    }
  }

  /**
   * Обновляет MMR после матча
   */
  static updateMMR(
    playerMMR: number,
    opponentMMR: number,
    playerWon: boolean
  ): number {
    const K = 32; // Коэффициент изменения
    const expectedScore =
      1 / (1 + Math.pow(10, (opponentMMR - playerMMR) / 400));

    const actualScore = playerWon ? 1 : 0;
    const ratingChange = K * (actualScore - expectedScore);

    return Math.round(playerMMR + ratingChange);
  }
}

export default MatchmakingService;