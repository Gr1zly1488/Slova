import { Router, Request, Response } from 'express';
import AuthService from '../services/authService';

const router = Router();

// Регистрация
router.post('/register', async (req: Request, res: Response) => {
  try {
    const { email, username, password } = req.body;

    if (!email || !username || !password) {
      return res
        .status(400)
        .json({ error: 'Email, username и пароль обязательны' });
    }

    const user = await AuthService.register(email, username, password);
    const token = AuthService.generateToken(user._id.toString());

    res.json({
      user: user.toJSON(),
      token,
    });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// Логин
router.post('/login', async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email и пароль обязательны' });
    }

    const user = await AuthService.login(email, password);
    const token = AuthService.generateToken(user._id.toString());

    res.json({
      user: user.toJSON(),
      token,
    });
  } catch (error: any) {
    res.status(401).json({ error: error.message });
  }
});

export default router;