// ⚠️ ДЕМО-ВЕРСИЯ - ТОЛЬКО ДЛЯ ОБУЧЕНИЯ
// Экран активной игры "Слова"

import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSocket } from '../../../hooks/useSocket';
import { useAppDispatch, useAppSelector } from '../../../store/store';
import { showNotification } from '../../../store/slices/notificationSlice';
import { GameQuestion } from './GameQuestion';
import { GameTimer } from './GameTimer';
import { AnswerButton } from './AnswerButton';
import { PlayerScoreboard } from './PlayerScoreboard';
import { RoundIndicator } from './RoundIndicator';
import { RoundResult } from '../results/RoundResult';
import { GameFinished } from '../results/GameFinished';

interface Player {
  id: string;
  username: string;
  avatar: string;
}

interface Round {
  questionId: string;
  player1Answer: number | null;
  player2Answer: number | null;
  winner: 'player1' | 'player2' | 'tie' | null;
}

interface Question {
  _id: string;
  text: string;
  answers: Array<{ _id: string | number; text: string }>;
  difficulty: string;
}

type GamePhase = 'loading' | 'question' | 'answered' | 'result' | 'finished';

interface GameRoomProps {
  gameId: string;
}

/**
 * Экран активной игры
 */
export const GameRoom = ({ gameId }: GameRoomProps) => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const { socket, isConnected } = useSocket();
  const { user } = useAppSelector((state) => state.auth);

  // ============ STATE ============

  // Игровое состояние
  const [gamePhase, setGamePhase] = useState<GamePhase>('loading');
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [player1, setPlayer1] = useState<Player | null>(null);
  const [player2, setPlayer2] = useState<Player | null>(null);
  const [currentRound, setCurrentRound] = useState(1);
  const [player1Score, setPlayer1Score] = useState(0);
  const [player2Score, setPlayer2Score] = useState(0);

  // Ответ игрока
  const [selectedAnswerIndex, setSelectedAnswerIndex] = useState<number | null>(null);
  const [answerSubmitted, setAnswerSubmitted] = useState(false);
  const [responseTime, setResponseTime] = useState(0);

  // Таймер
  const [timeLeft, setTimeLeft] = useState(30);
  const [timerActive, setTimerActive] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const startTimeRef = useRef<number>(0);

  // Результаты
  const [roundResult, setRoundResult] = useState<any>(null);
  const [gameResult, setGameResult] = useState<any>(null);
  const [isCurrentPlayerWinner, setIsCurrentPlayerWinner] = useState(false);

  // ============ SOCKET.IO ОБРАБОТЧИКИ ============

  useEffect(() => {
    if (!socket || !isConnected) {
      console.error('❌ Socket.io не подключен');
      return;
    }

    console.log('📡 Регистрируем Socket.io обработчики для игры:', gameId);

    // ========== ИНИЦИАЛИЗАЦИЯ ИГРЫ ==========

    /**
     * Игра создана, получаем информацию об игроках
     */
    socket.on('game:created', (data: any) => {
      console.log('✅ Игра создана:', data);
      setPlayer1(data.player1);
      setPlayer2(data.player2);
      dispatch(showNotification({
        type: 'success',
        message: `Матч начинается! ${data.player1.username} vs ${data.player2.username}`,
      }));
    });

    // ========== РАУНДЫ ==========

    /**
     * Новый раунд начался, получаем вопрос
     */
    socket.on('game:round-started', (data: any) => {
      console.log('🎯 Раунд начался:', data);
      setGamePhase('question');
      setCurrentRound(data.roundNumber);
      setCurrentQuestion(data.question);
      setSelectedAnswerIndex(null);
      setAnswerSubmitted(false);
      setTimeLeft(data.timerSeconds);
      setTimerActive(true);
      startTimeRef.current = Date.now();
      setRoundResult(null);

      dispatch(showNotification({
        type: 'info',
        message: `Раунд ${data.roundNumber} из 5. Вопрос для вас!`,
      }));
    });

    /**
     * Уведомление, что противник ответил
     */
    socket.on('game:player-answered', (data: any) => {
      console.log('📝 Противник ответил:', data);
      dispatch(showNotification({
        type: 'info',
        message: `${data.playerName} ответил!`,
      }));
    });

    /**
     * Обновление таймера (тик в секунду)
     */
    socket.on('game:timer-tick', (data: any) => {
      setTimeLeft(data.timeLeft);

      // Если время истекло и я ещё не ответил
      if (data.timeLeft <= 0 && !answerSubmitted) {
        setGamePhase('result');
        setAnswerSubmitted(true);
      }
    });

    /**
     * Раунд завершён, получаем результаты
     */
    socket.on('game:round-finished', (data: any) => {
      console.log('🏁 Раунд завершён:', data);
      setGamePhase('result');
      setTimerActive(false);

      // Обновля��м счёт
      setPlayer1Score(data.scores.player1);
      setPlayer2Score(data.scores.player2);

      // Сохраняем результат раунда
      setRoundResult({
        roundNumber: data.roundNumber,
        correctAnswerIndex: data.correctAnswerIndex,
        winner: data.winner,
        player1Answer: data.player1Answer,
        player2Answer: data.player2Answer,
        player1ResponseTime: data.player1ResponseTime,
        player2ResponseTime: data.player2ResponseTime,
        scores: data.scores,
        message: data.message,
      });

      // Проверяем, выиграл ли текущий игрок раунд
      if (user && player1 && player2) {
        const isPlayer1 = user._id === player1.id;
        const playerWon = 
          (isPlayer1 && data.winner === 'player1') || 
          (!isPlayer1 && data.winner === 'player2');
        setIsCurrentPlayerWinner(playerWon);
      }

      // Уведомляем пользователя
      if (data.winner) {
        dispatch(showNotification({
          type: 'success',
          message: data.message,
        }));
      }

      // Если это был последний раунд
      if (data.roundNumber >= 5) {
        // Переходим в финальный результат
        setTimeout(() => {
          setGamePhase('finished');
        }, 3000);
      }
    });

    // ========== КОНЕЦ ИГРЫ ==========

    /**
     * Игра завершена, получаем финальные результаты
     */
    socket.on('game:ended', (data: any) => {
      console.log('🏆 Игра завершена:', data);
      setGamePhase('finished');
      setTimerActive(false);

      // Сохраняем результат игры
      setGameResult({
        gameId: data.gameId,
        winner: data.winner,
        scores: data.scores,
        prizeAmount: data.prizeAmount,
        commission: data.commission,
        newBalances: data.newBalances,
        message: data.message,
      });

      // Уведомляем пользователя
      dispatch(showNotification({
        type: 'success',
        message: data.message,
        duration: 10000,
      }));
    });

    /**
     * Игрок отключился
     */
    socket.on('game:player-disconnected', (data: any) => {
      console.log('🔌 Игрок отключился:', data);
      dispatch(showNotification({
        type: 'error',
        message: data.message,
        duration: 10000,
      }));

      // Переходим обратно в лобби через 3 с��кунды
      setTimeout(() => {
        navigate('/lobby');
      }, 3000);
    });

    /**
     * Комната закрыта
     */
    socket.on('game:room-closed', () => {
      console.log('🗑️ Игровая комната закрыта');
      // Автоматически переходим в лобби
      setTimeout(() => {
        navigate('/lobby');
      }, 2000);
    });

    // ========== ОШИБКИ ==========

    socket.on('error', (data: any) => {
      console.error('❌ Ошибка сервера:', data);
      dispatch(showNotification({
        type: 'error',
        message: data.message || 'Ошибка в игре',
      }));
    });

    // Cleanup
    return () => {
      socket.off('game:created');
      socket.off('game:round-started');
      socket.off('game:player-answered');
      socket.off('game:timer-tick');
      socket.off('game:round-finished');
      socket.off('game:ended');
      socket.off('game:player-disconnected');
      socket.off('game:room-closed');
      socket.off('error');
    };
  }, [socket, isConnected, dispatch, navigate, user, player1, player2, answerSubmitted]);

  // ============ ТАЙМЕР ============

  useEffect(() => {
    if (!timerActive) return;

    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 0) {
          setTimerActive(false);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [timerActive]);

  // ============ ОБРАБОТЧИКИ СОБЫТИЙ ============

  /**
   * Отправка ответа на сервер
   */
  const handleSubmitAnswer = () => {
    if (selectedAnswerIndex === null) {
      dispatch(showNotification({
        type: 'warning',
        message: 'Выберите ответ перед отправкой',
      }));
      return;
    }

    if (!socket || !isConnected) {
      dispatch(showNotification({
        type: 'error',
        message: 'Нет соединения с сервером',
      }));
      return;
    }

    // Вычисляем время отклика
    const responseTime = Date.now() - startTimeRef.current;
    setResponseTime(responseTime);

    console.log(`📤 Отправка ответа: ${selectedAnswerIndex}, время: ${responseTime}ms`);

    // Отправляем ответ на сервер
    socket.emit('game:submit-answer', selectedAnswerIndex, responseTime);

    // Обновляем UI
    setAnswerSubmitted(true);
    setGamePhase('answered');
    setTimerActive(false);

    dispatch(showNotification({
      type: 'info',
      message: `Ответ отправлен (${(responseTime / 1000).toFixed(2)}s)`,
    }));
  };

  /**
   * Переход к следующему раунду
   */
  const handleNextRound = () => {
    if (!socket || !isConnected) return;

    console.log('⏭️ Переход к следующему раунду');
    socket.emit('game:next-round');
    setGamePhase('loading');
  };

  /**
   * Завершение игры
   */
  const handleEndGame = () => {
    if (!socket || !isConnected) return;

    console.log('🏆 Завершение игры');
    socket.emit('game:end');
  };

  /**
   * Возврат в лобби
   */
  const handleBackToLobby = () => {
    navigate('/lobby');
  };

  // ============ РЕНДЕР ============

  if (!player1 || !player2) {
    return (
      <div className="w-full h-full flex flex-col items-center justify-center bg-slate-950">
        <div className="space-y-4 text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-400 mx-auto"></div>
          <p className="text-xl text-white">⏳ Подготовка игры...</p>
          <p className="text-gray-400">Инициализация соединения</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full h-full bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-white overflow-hidden flex flex-col">
      {/* ========== ХЕДЕР - ИНФОРМАЦИЯ ОБ ИГРОКАХ ========== */}
      <div className="bg-slate-800/50 backdrop-blur-sm border-b border-slate-700 px-6 py-4">
        <div className="flex justify-between items-center">
          {/* Левый игрок */}
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-lg font-bold">
              {player1.avatar}
            </div>
            <div>
              <p className="font-bold text-sm">{player1.username}</p>
              <p className="text-xs text-gray-400">Игрок 1</p>
            </div>
          </div>

          {/* Счёт в центре */}
          <div className="text-center">
            <div className="text-3xl font-black">
              <span className={player1Score > player2Score ? 'text-green-400' : 'text-gray-400'}>
                {player1Score}
              </span>
              <span className="text-gray-500 mx-2">:</span>
              <span className={player2Score > player1Score ? 'text-green-400' : 'text-gray-400'}>
                {player2Score}
              </span>
            </div>
            <p className="text-xs text-gray-400 mt-1">Раунд {currentRound} из 5</p>
          </div>

          {/* Правый игрок */}
          <div className="flex items-center space-x-3 flex-row-reverse">
            <div className="w-12 h-12 bg-gradient-to-br from-pink-500 to-orange-500 rounded-full flex items-center justify-center text-lg font-bold">
              {player2.avatar}
            </div>
            <div className="text-right">
              <p className="font-bold text-sm">{player2.username}</p>
              <p className="text-xs text-gray-400">Игрок 2</p>
            </div>
          </div>
        </div>
      </div>

      {/* ========== ОСНОВНОЙ КОНТЕНТ ========== */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-8 overflow-y-auto">
        {gamePhase === 'loading' && (
          <div className="space-y-4 text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-400 mx-auto"></div>
            <p className="text-xl font-bold">Загрузка вопроса...</p>
            <p className="text-gray-400">Раунд {currentRound} из 5</p>
          </div>
        )}

        {gamePhase === 'question' && currentQuestion && (
          <div className="w-full max-w-2xl space-y-8">
            {/* Таймер */}
            <GameTimer timeLeft={timeLeft} maxTime={30} />

            {/* Вопрос */}
            <GameQuestion question={currentQuestion} />

            {/* Варианты ответов */}
            <div className="space-y-3">
              {currentQuestion.answers.map((answer, index) => (
                <AnswerButton
                  key={index}
                  index={index}
                  text={answer.text}
                  isSelected={selectedAnswerIndex === index}
                  onClick={() => setSelectedAnswerIndex(index)}
                  disabled={answerSubmitted}
                />
              ))}
            </div>

            {/* Кнопка отправки */}
            <button
              onClick={handleSubmitAnswer}
              disabled={selectedAnswerIndex === null || answerSubmitted}
              className={`
                w-full py-4 px-6 rounded-xl font-bold text-lg transition transform
                ${selectedAnswerIndex === null || answerSubmitted
                  ? 'bg-slate-700 text-gray-400 cursor-not-allowed'
                  : 'bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 active:scale-95'
                }
              `}
            >
              {answerSubmitted ? '⏳ Ожидание...' : '✓ Отправить ответ'}
            </button>
          </div>
        )}

        {gamePhase === 'answered' && (
          <div className="space-y-4 text-center">
            <div className="animate-pulse">
              <div className="text-5xl mb-4">⏳</div>
              <p className="text-2xl font-bold">Ответ получен!</p>
            </div>
            <p className="text-gray-400">Ожидаем завершения раунда...</p>
            <div className="mt-6">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-400 mx-auto"></div>
            </div>
          </div>
        )}

        {gamePhase === 'result' && roundResult && (
          <RoundResult
            result={roundResult}
            isCurrentPlayerWinner={isCurrentPlayerWinner}
            onContinue={currentRound >= 5 ? handleEndGame : handleNextRound}
            isFinalRound={currentRound >= 5}
          />
        )}

        {gamePhase === 'finished' && gameResult && (
          <GameFinished
            result={gameResult}
            isWinner={gameResult.winner === user?.username}
            onBackToLobby={handleBackToLobby}
          />
        )}
      </div>

      {/* ========== ИНДИКАТОР РАУНДОВ ========== */}
      <div className="bg-slate-800/50 backdrop-blur-sm border-t border-slate-700 px-6 py-4">
        <RoundIndicator currentRound={currentRound} totalRounds={5} />
      </div>
    </div>
  );
};

export default GameRoom;