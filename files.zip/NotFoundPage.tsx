import { Link } from 'react-router-dom';

/**
 * Страница 404 - не найдено
 */
export const NotFoundPage = () => {
  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center">
      <div className="text-center text-white space-y-6">
        <h1 className="text-6xl font-bold">404</h1>
        <p className="text-2xl">Страница не найдена</p>
        <p className="text-gray-400">
          Кажется, вы пришли не туда. Вернитесь в лобби.
        </p>
        <Link
          to="/lobby"
          className="inline-block px-6 py-3 bg-blue-600 hover:bg-blue-700 rounded-lg transition"
        >
          🏠 В лобби
        </Link>
      </div>
    </div>
  );
};

export default NotFoundPage;