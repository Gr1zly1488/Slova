// История завершённых матчей

import { Schema, model, Document, Types } from 'mongoose';

export interface IMatch extends Document {
  player1Id: Types.ObjectId;
  player2Id: Types.ObjectId;
  player1Username: string;
  player2Username: string;
  betAmount: number;
  winnerId: Types.ObjectId;
  winnerUsername: string;
  player1Score: number;
  player2Score: number;
  prizeMoney: number;
  platformCommission: number;
  gameId: Types.ObjectId; // Ссылка на активную игру (если нужна)
  duration: number; // В секундах
  createdAt: Date;
  updatedAt: Date;
}

const matchSchema = new Schema<IMatch>(
  {
    player1Id: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },

    player2Id: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },

    player1Username: {
      type: String,
      required: true,
    },

    player2Username: {
      type: String,
      required: true,
    },

    betAmount: {
      type: Number,
      required: true,
      min: 10,
      max: 50,
    },

    winnerId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },

    winnerUsername: {
      type: String,
      required: true,
    },

    player1Score: {
      type: Number,
      required: true,
      min: 0,
      max: 5,
    },

    player2Score: {
      type: Number,
      required: true,
      min: 0,
      max: 5,
    },

    prizeMoney: {
      type: Number,
      required: true,
      set: (value: number) => parseFloat(value.toFixed(2)),
    },

    platformCommission: {
      type: Number,
      required: true,
      set: (value: number) => parseFloat(value.toFixed(2)),
    },

    gameId: {
      type: Schema.Types.ObjectId,
      ref: 'Game',
    },

    duration: {
      type: Number,
      required: true,
      min: 0,
    },
  },
  {
    timestamps: true,
    collection: 'matches',
  }
);

// Индексы
matchSchema.index({ player1Id: 1, createdAt: -1 });
matchSchema.index({ player2Id: 1, createdAt: -1 });
matchSchema.index({ winnerId: 1, createdAt: -1 });
matchSchema.index({ createdAt: -1 }); // Для последних матчей

export const Match = model<IMatch>('Match', matchSchema);