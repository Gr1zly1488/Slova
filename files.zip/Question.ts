// ⚠️ ДЕМО-ВЕРСИЯ
// Вопросы для игры "Слова"

import { Schema, model, Document } from 'mongoose';

// ============ TYPESCRIPT INTERFACES ============

export interface IAnswer {
  text: string;
  isCorrect: boolean;
}

export interface IQuestion extends Document {
  text: string;
  answers: IAnswer[];
  category: string;
  difficulty: 'easy' | 'medium' | 'hard';
  explanation?: string; // Объяснение правильного ответа
  usageCount: number; // Сколько раз вопрос использовался в играх
  createdAt: Date;
  updatedAt: Date;

  // Methods
  getCorrectAnswerIndex(): number;
  toGameJSON(): Partial<IQuestion>; // Возвращает вопрос для клиента (без правильного ответа)
}

// ============ MONGOOSE SCHEMA ============

const answerSchema = new Schema<IAnswer>(
  {
    text: {
      type: String,
      required: [true, 'Текст ответа обязателен'],
      trim: true,
      minlength: [1, 'Текст ответа не может быть пустым'],
      maxlength: [500, 'Ответ слишком длинный'],
    },

    isCorrect: {
      type: Boolean,
      required: true,
      default: false,
    },
  },
  { _id: false } // Не создаём отдельный ID для ответов
);

const questionSchema = new Schema<IQuestion>(
  {
    text: {
      type: String,
      required: [true, 'Текст вопроса обязателен'],
      trim: true,
      minlength: [10, 'Вопрос должен быть минимум 10 символов'],
      maxlength: [1000, 'Вопрос слишком длинный'],
      index: true,
    },

    answers: {
      type: [answerSchema],
      required: true,
      validate: {
        validator: function (answers: IAnswer[]) {
          // Должно быть минимум 2 ответа
          if (answers.length < 2) return false;

          // Максимум 4 ответа
          if (answers.length > 4) return false;

          // Должен быть ровно один правильный ответ
          const correctAnswers = answers.filter((a) => a.isCorrect);
          return correctAnswers.length === 1;
        },
        message:
          'Должно быть 2-4 ответа, и ровно один из них должен быть правильным',
      },
    },

    category: {
      type: String,
      required: [true, 'Категория обязательна'],
      enum: [
        'история',
        'наука',
        'литература',
        'искусство',
        'спорт',
        'технология',
        'география',
        'другое',
      ],
      index: true,
    },

    difficulty: {
      type: String,
      required: true,
      enum: ['easy', 'medium', 'hard'],
      default: 'medium',
      index: true,
    },

    explanation: {
      type: String,
      trim: true,
      maxlength: [2000, 'Объяснение слишком длинное'],
    },

    usageCount: {
      type: Number,
      required: true,
      default: 0,
      min: 0,
    },
  },
  {
    timestamps: true,
    collection: 'questions',
  }
);

// ============ ИНДЕКСЫ ДЛЯ ПРОИЗВОДИТЕЛЬНОСТИ ============
questionSchema.index({ category: 1, difficulty: 1 }); // Для быстрого поиска вопросов по ��атегории и сложности
questionSchema.index({ usageCount: 1 }); // Для поиска редко используемых вопросов

// ============ МЕТОДЫ СХЕМЫ ============

/**
 * Возвращает индекс правильного ответа
 */
questionSchema.methods.getCorrectAnswerIndex = function (): number {
  return this.answers.findIndex((answer: IAnswer) => answer.isCorrect);
};

/**
 * Возвращает вопрос для отправки клиенту (без информации о правильном ответе)
 */
questionSchema.methods.toGameJSON = function () {
  return {
    _id: this._id,
    text: this.text,
    answers: this.answers.map((answer: IAnswer) => ({
      _id: Math.random(), // Временный ID для фронтенда
      text: answer.text,
    })),
    difficulty: this.difficulty,
  };
};

// ============ MIDDLEWARE - УВЕЛИЧЕНИЕ СЧЁТЧИКА ИСПОЛЬЗОВАНИЯ ============

/**
 * Увеличивает счётчик использования вопроса
 */
questionSchema.methods.incrementUsageCount = async function () {
  this.usageCount += 1;
  await this.save();
};

// ============ EXPORT ============
export const Question = model<IQuestion>('Question', questionSchema);