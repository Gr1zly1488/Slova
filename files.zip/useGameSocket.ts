import { useEffect, useState } from 'react';
import io, { Socket } from 'socket.io-client';

export const useGameSocket = () => {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [gameState, setGameState] = useState<any>(null);

  useEffect(() => {
    const newSocket = io(import.meta.env.VITE_API_URL, {
      auth: {
        token: localStorage.getItem('token'),
      },
    });

    newSocket.emit('user:register', localStorage.getItem('userId'));

    // Matchmaking
    newSocket.on('matchmaking:joined', (data) => {
      console.log('✅ В очереди matchmaking:', data);
    });

    // Game events
    newSocket.on('game:created', (data) => {
      console.log('✅ Матч создан:', data);
      setGameState(data);
    });

    newSocket.on('game:round-started', (data) => {
      console.log('✅ Раунд начался:', data);
      setGameState((prev) => ({ ...prev, ...data }));
    });

    newSocket.on('game:round-finished', (data) => {
      console.log('✅ Раунд завершён:', data);
      setGameState((prev) => ({ ...prev, ...data }));
    });

    newSocket.on('game:ended', (data) => {
      console.log('✅ Игра завершена:', data);
      setGameState(data);
    });

    setSocket(newSocket);

    return () => newSocket.close();
  }, []);

  const joinMatchmaking = (betAmount: number) => {
    socket?.emit('matchmaking:join', betAmount);
  };

  const submitAnswer = (answerIndex: number, responseTime: number) => {
    socket?.emit('game:submit-answer', answerIndex, responseTime);
  };

  const nextRound = () => {
    socket?.emit('game:next-round');
  };

  const endGame = () => {
    socket?.emit('game:end');
  };

  return {
    socket,
    gameState,
    joinMatchmaking,
    submitAnswer,
    nextRound,
    endGame,
  };
};