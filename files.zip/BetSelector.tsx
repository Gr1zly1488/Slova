interface BetSelectorProps {
  onSelect: (betAmount: number) => void;
  selectedBet?: number | null;
  disabled?: boolean;
  userBalance?: number;
}

const AVAILABLE_BETS = [10, 20, 50];

/**
 * Компонент для выбора ставки
 */
export const BetSelector = ({
  onSelect,
  selectedBet,
  disabled = false,
  userBalance = 0,
}: BetSelectorProps) => {
  return (
    <div className="grid grid-cols-3 gap-4">
      {AVAILABLE_BETS.map((bet) => {
        const canAfford = userBalance >= bet;
        const isSelected = selectedBet === bet;

        return (
          <button
            key={bet}
            onClick={() => onSelect(bet)}
            disabled={disabled || !canAfford}
            className={`
              relative p-6 rounded-xl font-bold text-lg transition duration-300
              ${isSelected
                ? 'bg-gradient-to-r from-blue-600 to-purple-600 scale-105 shadow-lg shadow-blue-500/50'
                : 'bg-slate-700 hover:bg-slate-600'
              }
              ${disabled || !canAfford ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
              border-2 ${isSelected ? 'border-blue-400' : 'border-slate-600'}
            `}
          >
            {/* Иконка */}
            <div className="text-3xl mb-2">💰</div>

            {/* Сумма */}
            <div className="text-2xl mb-1">${bet}</div>

            {/* Описание */}
            <div className="text-xs opacity-80">
              {bet === 10 && 'Новичок'}
              {bet === 20 && 'Профессионал'}
              {bet === 50 && 'Мастер'}
            </div>

            {/* Статус недоступности */}
            {!canAfford && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/30 rounded-xl">
                <span className="text-xs font-bold">Недостаточно средств</span>
              </div>
            )}
          </button>
        );
      })}
    </div>
  );
};