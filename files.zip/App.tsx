import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Provider } from 'react-redux';
import store from './store/store';

// Pages
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import LobbyPage from './pages/LobbyPage';
import GamePage from './pages/GamePage';
import ProfilePage from './pages/ProfilePage';
import WalletPage from './pages/WalletPage';
import NotFoundPage from './pages/NotFoundPage';

// Components
import { ProtectedRoute } from './components/auth/ProtectedRoute';
import { AuthGuard } from './components/auth/AuthGuard';
import { MainLayout } from './components/layout/MainLayout';
import { AuthLayout } from './components/layout/AuthLayout';
import { GameLayout } from './components/layout/GameLayout';

/**
 * ⚠️ ДЕМО-ВЕРСИЯ - ТОЛЬКО ДЛЯ ОБУЧЕНИЯ
 * Главный компонент приложения с роутингом
 */
function App() {
  return (
    <Provider store={store}>
      <Router>
        <Routes>
          {/* ============ AUTH МАРШРУТЫ (без хедера) ============ */}
          <Route element={<AuthLayout />}>
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
          </Route>

          {/* ============ ЗАЩИЩЁННЫЕ МАРШРУТЫ (с хедером) ============ */}
          <Route
            element={
              <ProtectedRoute>
                <MainLayout />
              </ProtectedRoute>
            }
          >
            {/* Лобби - главная страница */}
            <Route path="/" element={<LobbyPage />} />
            <Route path="/lobby" element={<LobbyPage />} />

            {/* Профиль и кошелёк */}
            <Route path="/profile" element={<ProfilePage />} />
            <Route path="/wallet" element={<WalletPage />} />
          </Route>

          {/* ============ ИГРОВЫЕ МАРШРУТЫ ============ */}
          <Route
            path="/game/:gameId"
            element={
              <ProtectedRoute>
                <GameLayout />
              </ProtectedRoute>
            }
          >
            <Route index element={<GamePage />} />
          </Route>

          {/* ============ СТРАНИЦА НЕ НАЙДЕНА ============ */}
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </Router>
    </Provider>
  );
}

export default App;