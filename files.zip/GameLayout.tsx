import { Outlet } from 'react-router-dom';
import { useEffect } from 'react';
import { useAppDispatch } from '../../store/store';
import { useSocket } from '../../hooks/useSocket';

/**
 * Лейаут для игровых страниц (полноэкранный режим)
 */
export const GameLayout = () => {
  const { socket } = useSocket();
  const dispatch = useAppDispatch();

  useEffect(() => {
    // Устанавливаем соединение при загрузке игры
    if (!socket?.connected) {
      console.log('📡 Подключение к Socket.io...');
    }
  }, [socket]);

  return (
    <div className="w-full h-screen bg-slate-950 text-white flex flex-col overflow-hidden">
      {/* Игровой контент */}
      <main className="flex-1 flex items-center justify-center">
        <Outlet />
      </main>
    </div>
  );
};

export default GameLayout;