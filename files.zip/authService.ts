import jwt from 'jsonwebtoken';
import { User, IUser } from '../models/User';

class AuthService {
  // Генерация JWT токена
  static generateToken(userId: string): string {
    return jwt.sign(
      { userId },
      process.env.JWT_SECRET!,
      { expiresIn: process.env.JWT_EXPIRE || '7d' }
    );
  }

  // Регистрация пользователя
  static async register(
    email: string,
    username: string,
    password: string
  ): Promise<IUser> {
    const existingUser = await User.findOne({
      $or: [{ email }, { username }],
    });

    if (existingUser) {
      throw new Error('Email или username уже зарегистрирован');
    }

    const user = new User({
      email,
      username,
      passwordHash: password,
    });

    await user.save();
    return user;
  }

  // Логин пользователя
  static async login(email: string, password: string): Promise<IUser> {
    const user = await User.findOne({ email }).select('+passwordHash');

    if (!user) {
      throw new Error('Пользователь не найден');
    }

    const isPasswordValid = await user.comparePassword(password);

    if (!isPasswordValid) {
      throw new Error('Неправильный пароль');
    }

    user.lastLogin = new Date();
    await user.save();

    return user;
  }

  // Верификация токена
  static verifyToken(token: string): string {
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET!) as {
        userId: string;
      };
      return decoded.userId;
    } catch (error) {
      throw new Error('Невалидный токен');
    }
  }
}

export default AuthService;