interface GameQuestionProps {
  question: {
    _id: string;
    text: string;
    difficulty: string;
  };
}

/**
 * Компонент отображения вопроса
 */
export const GameQuestion = ({ question }: GameQuestionProps) => {
  const difficultyColors = {
    easy: 'text-green-400',
    medium: 'text-yellow-400',
    hard: 'text-red-400',
  };

  const difficultyLabels = {
    easy: '🟢 Легко',
    medium: '🟡 Средне',
    hard: '🔴 Сложно',
  };

  return (
    <div className="bg-gradient-to-br from-slate-800 to-slate-700 rounded-2xl p-8 border border-slate-600">
      {/* Сложность */}
      <div className="mb-6">
        <span className={`text-sm font-bold ${difficultyColors[question.difficulty as keyof typeof difficultyColors]}`}>
          {difficultyLabels[question.difficulty as keyof typeof difficultyLabels]}
        </span>
      </div>

      {/* Текст вопроса */}
      <h2 className="text-3xl font-bold leading-relaxed mb-2">
        {question.text}
      </h2>

      {/* Разделитель */}
      <div className="h-1 w-16 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full mt-6"></div>
    </div>
  );
};