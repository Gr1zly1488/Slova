import { useState, useEffect } from 'react';

/**
 * Компонент отображения активных игр на сервере
 */
export const ActiveGames = () => {
  const [games, setGames] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // TODO: Загрузить активные игры с API
    setLoading(false);
  }, []);

  if (loading) {
    return (
      <div className="text-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-400 mx-auto"></div>
      </div>
    );
  }

  if (games.length === 0) {
    return (
      <div className="text-center py-8 text-gray-400">
        <p>Активных игр нет</p>
        <p className="text-sm">Начните новую игру для участия</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {games.map((game) => (
        <div
          key={game.id}
          className="bg-slate-700/50 rounded-lg p-4 flex justify-between items-center hover:bg-slate-700 transition"
        >
          <div>
            <p className="font-bold">{game.player1} vs {game.player2}</p>
            <p className="text-sm text-gray-400">Ставка: ${game.betAmount}</p>
          </div>
          <div className="text-right">
            <p className="font-bold text-yellow-400">${game.betAmount * 2}</p>
            <p className="text-xs text-gray-400">в банке</p>
          </div>
        </div>
      ))}
    </div>
  );
};