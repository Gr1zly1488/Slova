import { Schema, model, Document, Types } from 'mongoose';

export interface IPayment extends Document {
  userId: Types.ObjectId;
  amount: number;
  status: 'pending' | 'completed' | 'failed' | 'refunded';
  type: 'deposit' | 'withdrawal';
  stripeSessionId?: string;
  stripePaymentIntentId?: string;
  stripeChargeId?: string;
  createdAt: Date;
  updatedAt: Date;
}

const paymentSchema = new Schema<IPayment>(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'User ID об��зателен'],
      index: true,
    },

    amount: {
      type: Number,
      required: [true, 'Сумма обязательна'],
      min: [10, 'Минимальная сумма 10 USD'],
      max: [1000, 'Максимальная сумма 1000 USD'],
      set: (value: number) => parseFloat(value.toFixed(2)),
    },

    status: {
      type: String,
      enum: ['pending', 'completed', 'failed', 'refunded'],
      default: 'pending',
      index: true,
    },

    type: {
      type: String,
      enum: ['deposit', 'withdrawal'],
      required: true,
      index: true,
    },

    stripeSessionId: {
      type: String,
      index: true,
    },

    stripePaymentIntentId: {
      type: String,
      index: true,
    },

    stripeChargeId: {
      type: String,
      index: true,
    },
  },
  {
    timestamps: true,
    collection: 'payments',
  }
);

// Индексы
paymentSchema.index({ userId: 1, createdAt: -1 });
paymentSchema.index({ status: 1, createdAt: -1 });

export const Payment = model<IPayment>('Payment', paymentSchema);