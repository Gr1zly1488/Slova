interface WaitingForOpponentProps {
  betAmount: number;
  onCancel: () => void;
  timeLeft?: number;
}

/**
 * Компонент ожидания соперника
 */
export const WaitingForOpponent = ({
  betAmount,
  onCancel,
  timeLeft = 0,
}: WaitingForOpponentProps) => {
  return (
    <div className="bg-gradient-to-b from-blue-900/30 to-purple-900/30 backdrop-blur-sm rounded-2xl p-12 border border-blue-700/50">
      <div className="text-center space-y-8">
        {/* Анимированный поиск */}
        <div className="flex justify-center">
          <div className="relative w-24 h-24">
            <div className="absolute inset-0 rounded-full border-4 border-transparent border-t-blue-400 border-r-purple-400 animate-spin"></div>
            <div className="absolute inset-2 rounded-full border-4 border-transparent border-b-blue-400 border-l-purple-400 animate-spin" style={{ animationDirection: 'reverse' }}></div>
            <div className="absolute inset-0 flex items-center justify-center text-3xl">🔍</div>
          </div>
        </div>

        {/* Статус */}
        <div>
          <h2 className="text-3xl font-bold mb-2">🔎 Поиск соперника</h2>
          <p className="text-gray-300">Ставка: <span className="font-bold text-yellow-400">${betAmount}</span></p>
        </div>

        {/* Таймер */}
        <div className="bg-slate-800/50 rounded-lg px-6 py-3 inline-block">
          <p className="text-sm text-gray-400">Максимальное время поиска</p>
          <div className="text-4xl font-bold text-blue-400 mt-2">
            {timeLeft}с
          </div>
        </div>

        {/* Сообщение */}
        <div className="space-y-2">
          <p className="text-gray-300 animate-pulse">
            Ожидаем соперника...
          </p>
          <div className="flex justify-center space-x-1">
            <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0s' }}></div>
            <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
            <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
          </div>
        </div>

        {/* Кнопка отмены */}
        <button
          onClick={onCancel}
          className="px-8 py-3 bg-red-600 hover:bg-red-700 rounded-xl font-bold transition transform hover:scale-105"
        >
          ❌ Отменить поиск
        </button>
      </div>
    </div>
  );
};