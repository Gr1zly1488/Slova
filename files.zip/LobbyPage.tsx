// ⚠️ ДЕМО-ВЕРСИЯ - ТОЛЬКО ДЛЯ ОБУЧЕНИЯ
// Лобби - главная страница приложения "Слова"

import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppDispatch, useAppSelector } from '../store/store';
import { useSocket } from '../hooks/useSocket';
import { BetSelector } from '../components/game/matchmaking/BetSelector';
import { WaitingForOpponent } from '../components/game/matchmaking/WaitingForOpponent';
import { ActiveGames } from '../components/game/matchmaking/ActiveGames';
import { WalletDisplay } from '../components/wallet/WalletDisplay';
import { GameHistory } from '../components/game/GameHistory';
import { showNotification } from '../store/slices/notificationSlice';
import { setCurrentGame } from '../store/slices/gameSlice';

type MatchmakingState = 'idle' | 'searching' | 'found' | 'error';

/**
 * Лобби - главная страница приложения
 * - Выбор ставки
 * - Поиск соперника (Socket.io matchmaking)
 * - Отображение баланса
 * - История игр
 */
export const LobbyPage = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const { socket, isConnected } = useSocket();

  // Redux state
  const { user } = useAppSelector((state) => state.auth);
  const gameState = useAppSelector((state) => state.matchmaking);

  // Local state
  const [matchmakingState, setMatchmakingState] = useState<MatchmakingState>('idle');
  const [selectedBet, setSelectedBet] = useState<number | null>(null);
  const [opponentInfo, setOpponentInfo] = useState<any>(null);
  const [searchTimeLeft, setSearchTimeLeft] = useState(0);
  const [showGameHistory, setShowGameHistory] = useState(false);

  // ============ SOCKET.IO ОБРАБОТЧИКИ ============

  useEffect(() => {
    if (!socket || !isConnected) return;

    console.log('📡 Socket.io готов, регистрируем слушатели...');

    // Регистрируем пользователя при подключении
    const userId = localStorage.getItem('userId');
    if (userId) {
      socket.emit('user:register', userId);
    }

    // ========== MATCHMAKING СОБЫТИЯ ==========

    /**
     * Пользователь присоединился к очереди
     */
    socket.on('matchmaking:joined', (data: any) => {
      console.log('✅ Присоединились к очереди matchmaking:', data);
      setMatchmakingState('searching');
      setSearchTimeLeft(60); // Максимум 60 секунд поиска

      dispatch(
        showNotification({
          type: 'info',
          message: `Поиск соперника... (Позиция: ${data.position})`,
        })
      );
    });

    /**
     * Матч найден, игра создана
     */
    socket.on('game:created', (data: any) => {
      console.log('✅ Матч найден! Игра создана:', data);
      setMatchmakingState('found');
      setOpponentInfo(data);

      dispatch(
        showNotification({
          type: 'success',
          message: `🎉 Матч найден! Противни��: ${data.player2.username}`,
        })
      );

      // Через 3 секунды переходим в игру
      setTimeout(() => {
        dispatch(setCurrentGame({
          gameId: data.gameId,
          player1: data.player1,
          player2: data.player2,
          betAmount: data.betAmount || selectedBet,
          status: 'active',
        }));
        navigate(`/game/${data.gameId}`);
      }, 3000);
    });

    /**
     * Matchmaking отменён
     */
    socket.on('matchmaking:cancelled', (data: any) => {
      console.log('❌ Matchmaking отменён:', data);
      setMatchmakingState('idle');
      setSelectedBet(null);
      setOpponentInfo(null);

      dispatch(
        showNotification({
          type: 'info',
          message: 'Поиск соперника отменён',
        })
      );
    });

    // ========== ОШИБКИ ==========

    /**
     * Ошибка при matchmaking
     */
    socket.on('error', (data: any) => {
      console.error('❌ Ошибка от сервера:', data.message);
      setMatchmakingState('error');

      dispatch(
        showNotification({
          type: 'error',
          message: data.message || 'Ошибка при поиске соперника',
        })
      );

      // Возвращаемся в idle через 2 секунды
      setTimeout(() => {
        setMatchmakingState('idle');
        setSelectedBet(null);
      }, 2000);
    });

    // ========== ОТКЛЮЧЕНИЕ СОЕДИНЕНИЯ ==========

    socket.on('disconnect', () => {
      console.log('🔌 Соединение разорвано');
      dispatch(
        showNotification({
          type: 'warning',
          message: 'Потеряно соединение с сервером',
        })
      );
    });

    socket.on('connect', () => {
      console.log('📡 Соединение восстановлено');
      dispatch(
        showNotification({
          type: 'success',
          message: 'Соединение восстановлено',
        })
      );
    });

    // Cleanup
    return () => {
      socket.off('matchmaking:joined');
      socket.off('game:created');
      socket.off('matchmaking:cancelled');
      socket.off('error');
      socket.off('disconnect');
      socket.off('connect');
    };
  }, [socket, isConnected, dispatch, navigate, selectedBet]);

  // ============ ТАЙМЕР ПОИСКА ============

  useEffect(() => {
    if (matchmakingState !== 'searching') return;

    const timer = setInterval(() => {
      setSearchTimeLeft((prev) => {
        if (prev <= 1) {
          // Время истекло - отмена поиска
          handleCancelSearch();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [matchmakingState]);

  // ============ ОБРАБОТЧИКИ СОБЫТИЙ ============

  /**
   * Начало поиска соперника
   */
  const handleStartSearch = (betAmount: number) => {
    // Проверяем баланс
    if (!user || user.balance < betAmount) {
      dispatch(
        showNotification({
          type: 'error',
          message: 'Недостаточно средств на балансе',
        })
      );
      return;
    }

    // Проверяем соединение
    if (!socket || !isConnected) {
      dispatch(
        showNotification({
          type: 'error',
          message: 'Нет соединения с сервером',
        })
      );
      return;
    }

    console.log(`🎮 Начало поиска соперника. Ставка: ${betAmount} USD`);
    setSelectedBet(betAmount);

    // Отправляем запрос на matchmaking
    socket.emit('matchmaking:join', betAmount);
  };

  /**
   * Отмена поиска
   */
  const handleCancelSearch = () => {
    console.log('❌ Отмена поиска ��оперника');

    if (socket && isConnected) {
      socket.emit('matchmaking:cancel');
    }

    setMatchmakingState('idle');
    setSelectedBet(null);
    setOpponentInfo(null);
    setSearchTimeLeft(0);
  };

  // ============ РЕНДЕР ============

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Фоновые эффекты */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-blob"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-blue-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-blob animation-delay-2000"></div>
        <div className="absolute top-1/2 left-1/2 w-80 h-80 bg-pink-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-blob animation-delay-4000"></div>
      </div>

      {/* Контент */}
      <div className="relative z-10 container mx-auto px-4 py-8">
        {/* Статус соединения */}
        <div className="mb-6">
          {isConnected ? (
            <div className="inline-flex items-center space-x-2 px-4 py-2 bg-green-900/30 border border-green-700/50 rounded-lg">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-green-300 text-sm">✅ Соединение активно</span>
            </div>
          ) : (
            <div className="inline-flex items-center space-x-2 px-4 py-2 bg-red-900/30 border border-red-700/50 rounded-lg">
              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
              <span className="text-red-300 text-sm">❌ Нет соединения</span>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* ========== ЛЕВАЯ КОЛОНКА - ВЫБОР СТАВКИ ========== */}
          <div className="lg:col-span-2 space-y-8">
            {/* Заголовок */}
            <div className="text-center mb-8">
              <h1 className="text-5xl font-black mb-3 bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                🎮 Слова
              </h1>
              <p className="text-gray-400 text-lg">
                Выигрыв��й денежные призы в словесной дуэли
              </p>
            </div>

            {/* ========== ВЫБОР СТАВКИ ИЛИ ОЖИДАНИЕ ========== */}
            {matchmakingState === 'idle' || matchmakingState === 'error' ? (
              <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl p-8 border border-slate-700/50 hover:border-slate-600/50 transition">
                <h2 className="text-3xl font-bold mb-8 text-center">
                  💰 Выберите ставку
                </h2>

                <BetSelector
                  onSelect={handleStartSearch}
                  selectedBet={selectedBet}
                  disabled={!isConnected || !user || user.balance === 0}
                  userBalance={user?.balance || 0}
                />

                {user && user.balance < 10 && (
                  <div className="mt-6 p-4 bg-yellow-900/30 border border-yellow-700/50 rounded-lg">
                    <p className="text-yellow-300 text-sm">
                      ⚠️ Минимальная ставка: 10 USD. Пополните баланс для игры.
                    </p>
                  </div>
                )}
              </div>
            ) : matchmakingState === 'searching' ? (
              <WaitingForOpponent
                betAmount={selectedBet || 0}
                onCancel={handleCancelSearch}
                timeLeft={searchTimeLeft}
              />
            ) : matchmakingState === 'found' ? (
              <div className="bg-gradient-to-r from-green-900/30 to-blue-900/30 backdrop-blur-sm rounded-2xl p-8 border border-green-700/50">
                <div className="text-center space-y-4">
                  <h2 className="text-3xl font-bold text-green-300">
                    ✅ Матч найден!
                  </h2>
                  <p className="text-gray-300">
                    Противник: <span className="font-bold text-white">{opponentInfo?.player2?.username}</span>
                  </p>
                  <p className="text-gray-300">
                    Ставка: <span className="font-bold text-yellow-400">${selectedBet}</span>
                  </p>
                  <div className="pt-4">
                    <div className="inline-block">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-400"></div>
                    </div>
                    <p className="text-sm text-gray-400 mt-3">Переход в игру...</p>
                  </div>
                </div>
              </div>
            ) : null}

            {/* ========== АКТИВНЫЕ ИГРЫ ========== */}
            <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl p-8 border border-slate-700/50">
              <h3 className="text-2xl font-bold mb-6">🎯 Активные игры</h3>
              <ActiveGames />
            </div>
          </div>

          {/* ========== ПРАВАЯ КОЛОНКА - КОШЕЛЁК И СТАТИСТИКА ========== */}
          <div className="space-y-6">
            {/* Баланс */}
            <WalletDisplay user={user} onDepositClick={() => navigate('/wallet')} />

            {/* Меню */}
            <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/50 space-y-3">
              <h3 className="font-bold text-lg mb-4">🔗 Меню</h3>
              <nav className="space-y-3">
                <button
                  onClick={() => navigate('/profile')}
                  className="w-full px-4 py-3 bg-slate-700/50 hover:bg-slate-600 rounded-lg transition text-left font-medium"
                >
                  👤 Профиль
                </button>
                <button
                  onClick={() => navigate('/wallet')}
                  className="w-full px-4 py-3 bg-slate-700/50 hover:bg-slate-600 rounded-lg transition text-left font-medium"
                >
                  💳 Кошелёк
                </button>
                <button
                  onClick={() => setShowGameHistory(!showGameHistory)}
                  className="w-full px-4 py-3 bg-slate-700/50 hover:bg-slate-600 rounded-lg transition text-left font-medium"
                >
                  📜 История игр
                </button>
              </nav>
            </div>

            {/* Статистика */}
            {user && (
              <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/50">
                <h3 className="font-bold text-lg mb-4">📊 Статистика</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Игр сыграно:</span>
                    <span className="font-bold text-white">{user.totalGamesPlayed}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Побед:</span>
                    <span className="font-bold text-green-400">{user.totalWins}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Поражений:</span>
                    <span className="font-bold text-red-400">{user.totalLosses}</span>
                  </div>
                  <div className="border-t border-slate-700 pt-3 mt-3 flex justify-between">
                    <span className="text-gray-400">Win Rate:</span>
                    <span className="font-bold text-blue-400">
                      {user.totalGamesPlayed > 0
                        ? ((user.totalWins / user.totalGamesPlayed) * 100).toFixed(1)
                        : 0}
                      %
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Информация */}
            <div className="bg-blue-900/20 border border-blue-700/50 rounded-2xl p-4 text-xs">
              <p className="text-blue-300 leading-relaxed">
                💡 <strong>Совет:</strong> Выбирайте ставку в зависимости от вашего мастерства.
                Выиграйте все 5 раундов и возьмите банк!
              </p>
            </div>

            {/* Disclaimer */}
            <div className="bg-yellow-900/20 border border-yellow-700/50 rounded-2xl p-4 text-xs">
              <p className="text-yellow-300 leading-relaxed">
                ⚠️ <strong>Внимание:</strong> Это демо-версия. Реальные азартные игры требуют лицензирования.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Модальное окно истории игр */}
      {showGameHistory && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-slate-800 rounded-2xl p-8 max-w-2xl w-full max-h-[80vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold">📜 История игр</h2>
              <button
                onClick={() => setShowGameHistory(false)}
                className="text-gray-400 hover:text-white text-2xl"
              >
                ✕
              </button>
            </div>
            <GameHistory />
          </div>
        </div>
      )}
    </div>
  );
};

export default LobbyPage;