interface GameTimerProps {
  timeLeft: number;
  maxTime: number;
}

/**
 * Компонент таймера
 */
export const GameTimer = ({ timeLeft, maxTime }: GameTimerProps) => {
  // Вычисляем процент оставшегося времени
  const percentage = (timeLeft / maxTime) * 100;

  // Выбираем цвет в зависимости от времени
  let timerColor = 'text-green-400';
  let ringColor = 'from-green-500 to-blue-500';

  if (percentage <= 33) {
    timerColor = 'text-red-400';
    ringColor = 'from-red-500 to-orange-500';
  } else if (percentage <= 66) {
    timerColor = 'text-yellow-400';
    ringColor = 'from-yellow-500 to-orange-500';
  }

  return (
    <div className="flex justify-center">
      <div className="relative w-32 h-32">
        {/* Фоновый круг */}
        <svg className="w-full h-full transform -rotate-90" viewBox="0 0 120 120">
          <circle
            cx="60"
            cy="60"
            r="55"
            fill="none"
            stroke="#334155"
            strokeWidth="6"
          />
          {/* Прогресс круг */}
          <circle
            cx="60"
            cy="60"
            r="55"
            fill="none"
            stroke="url(#gradient)"
            strokeWidth="6"
            strokeDasharray={`${(percentage / 100) * 2 * Math.PI * 55} ${2 * Math.PI * 55}`}
            style={{ transition: 'stroke-dasharray 1s linear' }}
          />
          <defs>
            <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" className={`stop-color-${ringColor.split('-')[1]}`} />
              <stop offset="100%" className={`stop-color-${ringColor.split('-')[2]}`} />
            </linearGradient>
          </defs>
        </svg>

        {/* Время в центре */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            <div className={`text-4xl font-black ${timerColor}`}>
              {timeLeft}
            </div>
            <div className="text-xs text-gray-400 mt-1">сек</div>
          </div>
        </div>
      </div>
    </div>
  );
};