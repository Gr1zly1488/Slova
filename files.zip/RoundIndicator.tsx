interface RoundIndicatorProps {
  currentRound: number;
  totalRounds: number;
}

/**
 * Компонент индикатора раундов
 */
export const RoundIndicator = ({ currentRound, totalRounds }: RoundIndicatorProps) => {
  return (
    <div className="flex justify-center items-center space-x-2">
      {Array.from({ length: totalRounds }).map((_, index) => {
        const round = index + 1;
        const isCompleted = round < currentRound;
        const isCurrent = round === currentRound;

        return (
          <div
            key={round}
            className={`
              w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm
              transition duration-300
              ${isCurrent
                ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white scale-110 shadow-lg'
                : isCompleted
                ? 'bg-green-600 text-white'
                : 'bg-slate-700 text-gray-400'
              }
            `}
          >
            {isCompleted ? '✓' : round}
          </div>
        );
      })}
    </div>
  );
};