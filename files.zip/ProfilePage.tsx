import { ProfileHeader } from '../components/profile/ProfileHeader';
import { ProfileStats } from '../components/profile/ProfileStats';
import { AchievementBadges } from '../components/profile/AchievementBadges';
import { useAppSelector } from '../store/store';

/**
 * Страница профиля пользователя
 */
export const ProfilePage = () => {
  const { user } = useAppSelector((state) => state.auth);

  if (!user) {
    return <div className="text-white text-center">⏳ Загрузка...</div>;
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <ProfileHeader user={user} />
      <ProfileStats user={user} />
      <AchievementBadges />
    </div>
  );
};

export default ProfilePage;