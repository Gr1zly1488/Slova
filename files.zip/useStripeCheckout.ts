import { loadStripe } from '@stripe/stripe-js';

export const useStripeCheckout = () => {
  const createCheckoutSession = async (amount: number) => {
    try {
      const response = await fetch('/api/v1/payment/create-checkout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify({ amount }),
      });

      const data = await response.json();

      if (data.checkoutUrl) {
        window.location.href = data.checkoutUrl;
      }
    } catch (error) {
      console.error('Ошибка при создании checkout:', error);
    }
  };

  return { createCheckoutSession };
};